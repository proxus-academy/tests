<!DOCTYPE html>
<html lang="es">
<head>
    <title>Gráfico de Intentos de Test</title>
    <!-- Incluir Chart.js desde una CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
</head>
<body>
<?php
session_start();

require 'includes/Aplicacion.php';

$db = Aplicacion::getInstance()->getConnection(); // Obtener la conexión usando el patrón Singleton

include 'includes/comun/header.php';?>

<div class="container">
    <?php
    $test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : null;
    $user_id = $_SESSION['ID_usuario'];
    
    if (!$test_id) {
        exit('El ID del test no está definido.');
    }
    
    // Recuperar resultados de la sesión
    $resultados = $_SESSION['resultados_test'] ?? null;
    if (!$resultados) {
        exit('No hay resultados disponibles para mostrar.');
    }

    // Obtener el título y número actualizado de preguntas del test
    $stmt = $db->prepare("SELECT titulo, num_preguntas FROM tests WHERE ID_test = ?");
    $stmt->bindParam(1, $test_id, PDO::PARAM_INT);
    $stmt->execute();
    $row_test = $stmt->fetch(PDO::FETCH_ASSOC);
    $titulo_test = $row_test ? $row_test['titulo'] : "Desconocido";
    $total_preguntas = $row_test ? $row_test['num_preguntas'] : 0;


    $stmt = $db->prepare("SELECT COUNT(*) AS total_intentos, AVG(nota) AS nota_media, SUM(aciertos) AS total_aciertos FROM respuesta_usuario WHERE ID_test = ? AND ID_usuario = ?");
    $stmt->bindParam(1, $test_id, PDO::PARAM_INT);
    $stmt->bindParam(2, $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $row_intentos = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Mostrar resultados
    $total_preguntas = $resultados['total_preguntas'];
    $aciertos = $resultados['aciertos'];
    $fallos = $resultados['fallos'];
    $respuestas_en_blanco = $resultados['respuestas_en_blanco'];
    $nota = $resultados['nota'];    
    ?>
    <h2>Resultados de: '<?php echo $titulo_test; ?>'</h2>
    <div style='text-align: center; margin-top: 25px'>
        <h3>En este intento has obtenido...</h3>
        <table style='min-width: 310px; margin: auto;'>
            <tr><th>Evaluación</th><th>Valor</th></tr>
            <tr><td>Preguntas totales</td><td><?php echo $total_preguntas; ?></td></tr>
            <tr><td>Aciertos</td><td><?php echo $aciertos; ?></td></tr>
            <tr><td>Fallos</td><td><?php echo $fallos; ?></td></tr>
            <tr><td>Respuestas en blanco</td><td><?php echo $respuestas_en_blanco; ?></td></tr>
            <tr><td>Nota</td><td><?php echo $nota; ?> / 10</td></tr>
        </table>
    </div>

    <?php
    $total_intentos = $row_intentos['total_intentos'] ?? 0;
    $nota_media = $row_intentos['nota_media'] ? round($row_intentos['nota_media'], 2) : 0;
    $total_aciertos = $row_intentos['total_aciertos'] ?? 0;
    $porcentaje_aciertos = ($total_preguntas * $total_intentos) > 0 ? round(($total_aciertos / ($total_preguntas * $total_intentos)) * 100, 2) : 0;

    echo "<div style='text-align: center; margin-top: 25px'>";
    echo "<h3>Estadísticas de todos los intentos</h3>";
    echo "<table style='min-width: 310px; margin: auto;'>";
    echo "<tr><th>Evaluación</th><th>Valor</th></tr>";
    echo "<tr><td>Número total de intentos</td><td>$total_intentos</td></tr>";
    echo "<tr><td>Nota media entre todos los intentos</td><td>$nota_media / 10</td></tr>";
    echo "<tr><td>Porcentaje de aciertos entre todos los intentos</td><td>$porcentaje_aciertos%</td></tr>";
    echo "</table></div>";
    ?>
    <canvas id="intentosChart" width="400" height="200" style="margin-top: 25px;"></canvas>

    <div class="centered-link-container">
        <button id="toggleChartType" class="submit-button">Cambiar Gráfico</button>
    </div>

    <div class="centered-link-container">
        <?php if ($titulo_test == "Simulacro Examen" ): ?>
            <a href="realize_test_simulacro_fal.php?id=<?php echo htmlspecialchars($test_id); ?>" class="buttonT">Repetir Test</a>
        <?php else: ?>
            <a href="realize_test.php?id=<?php echo htmlspecialchars($test_id); ?>" class="buttonT">Repetir Test</a>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/comun/footer.php'; ?>

<script>
    // Pasar variables de PHP a JavaScript
    var testId = <?php echo json_encode($test_id); ?>;
    var userId = <?php echo json_encode($user_id); ?>;

</script>   
<script src="js/grafica_resultados.js"></script>

</body>
</html>