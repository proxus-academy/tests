// Obtener el contexto del lienzo de la gráfica
var ctx = document.getElementById('intentosChart').getContext('2d');
var intentosChart; // Referencia global para el gráfico
var currentChartType = 'line'; // Tipo de gráfico actual

// Función para crear o actualizar el gráfico
function createOrUpdateChart(data) {
    if (intentosChart) {
        intentosChart.destroy(); // Destruir el gráfico existente para recrearlo
    }
    intentosChart = new Chart(ctx, {
        type: currentChartType,
        data: {
            labels: data.fechas,
            datasets: [{
                label: 'Notas',
                data: data.notas,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            plugins: {
                title: {
                    display: true,
                    text: 'Evolución de las notas en los intentos del test'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Manejar el clic en el botón para cambiar el tipo de gráfico
document.getElementById('toggleChartType').addEventListener('click', function() {
    currentChartType = (currentChartType === 'line') ? 'bar' : 'line'; // Cambiar el tipo de gráfico
    fetchDataAndCreateChart(); // Volver a obtener datos y crear el gráfico
});

// Función para obtener los datos del servidor y crear/actualizar el gráfico
function fetchDataAndCreateChart() {
    fetch('logic/obtener_datos_intentos.php?test_id=' + testId + '&user_id=' + userId)
        .then(response => response.json())
        .then(data => {
            createOrUpdateChart(data);
        })
        .catch(error => {
            console.error('Error al obtener los datos de los intentos:', error);
        });
}

// Inicializar el gráfico al cargar la página
fetchDataAndCreateChart();
