function validateForm() {
    let isValid = true;
    const errorContainers = {
        nombre: document.getElementById('error-nombre'),
        apellidos: document.getElementById('error-apellidos'),
        email: document.getElementById('error-email'),
        user: document.getElementById('error-user'),
        psw: document.getElementById('error-psw'),
        psw_confirm: document.getElementById('error-psw-confirm'),
        codigo_registro: document.getElementById('error-codigo_registro') // Agregado para el código de registro
    };

    // Limpiar mensajes de error previos
    Object.values(errorContainers).forEach(container => container.textContent = '');

    // Validaciones de ejemplo (se pueden expandir según necesites)
    if (!document.getElementById('nombre').value.trim()) {
        errorContainers.nombre.textContent = 'El nombre es obligatorio.';
        isValid = false;
    }
    if (!document.getElementById('email').value.includes('@')) {
        errorContainers.email.textContent = 'El email no es válido.';
        isValid = false;
    }
    if (document.getElementById('psw').value !== document.getElementById('psw-confirm').value) {
        errorContainers.psw_confirm.textContent = 'Las contraseñas no coinciden.';
        isValid = false;
    }
    if (!document.getElementById('codigo_registro').value.trim()) {
        errorContainers.codigo_registro.textContent = 'El código de registro es obligatorio.';
        isValid = false;
    }

    return isValid; 
}

function submitForm(event) {
    event.preventDefault(); // Evitar que el formulario se envíe automáticamente

    // Validación del formulario antes del envío
    if (!validateForm()) {
        return; // Si el formulario no es válido, detener la ejecución
    }

    var formData = new FormData(document.getElementById('signup-form'));

    fetch('logic/sign_up_logic.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = data.redirect; // Redireccionar si es necesario
        } else {
            // Mostrar mensajes de error según el campo que tenga el error
            if (data.errors) {
                for (let field in data.errors) {
                    let errorContainer = document.getElementById('error-' + field);
                    if (errorContainer) {
                        errorContainer.textContent = data.errors[field];
                    }
                }
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('signup-form').addEventListener('submit', submitForm);
});