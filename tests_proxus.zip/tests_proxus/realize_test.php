<!DOCTYPE html>
<html lang="es">
<head>

    <?php
        session_start();

        require_once 'includes/Aplicacion.php';
        $db = Aplicacion::getInstance()->getConnection(); // Obtener la conexión usando el patrón Singleton
        
        $test_id = isset($_GET['id']) ? intval($_GET['id']) : null;
        
        if ($test_id === null) {
            exit('El ID del test no está definido.');
        }
        
        // Preparar y ejecutar la consulta para obtener el título del test
        $stmtTitulo = $db->prepare("SELECT titulo FROM tests WHERE ID_test = ?");
        $stmtTitulo->bindValue(1, $test_id, PDO::PARAM_INT);
        $stmtTitulo->execute();
        $tituloTest = $stmtTitulo->rowCount() > 0 ? $stmtTitulo->fetch(PDO::FETCH_ASSOC)['titulo'] : "Título no encontrado";

        // Preparar y ejecutar la consulta para obtener el nombre de la asignatura
        $stmtAsignatura = $db->prepare("SELECT asignaturas.nombre FROM asignaturas INNER JOIN test_asignatura ON asignaturas.ID_asignatura = test_asignatura.ID_asignatura WHERE test_asignatura.ID_test = ?");
        $stmtAsignatura->bindValue(1, $test_id, PDO::PARAM_INT);
        $stmtAsignatura->execute();
        $nombreAsignatura = $stmtAsignatura->rowCount() > 0 ? $stmtAsignatura->fetch(PDO::FETCH_ASSOC)['nombre'] : "Asignatura no encontrada";

        // Preparar y ejecutar la consulta para obtener las preguntas
        $stmtPreguntas = $db->prepare("SELECT preguntas.ID_pregunta, preguntas.pregunta FROM preguntas WHERE preguntas.ID_test = ?");
        $stmtPreguntas->bindValue(1, $test_id, PDO::PARAM_INT);
        $stmtPreguntas->execute();
        $preguntas = $stmtPreguntas->fetchAll(PDO::FETCH_ASSOC);

        // Barajar preguntas
        shuffle($preguntas);
        $_SESSION['preguntas_test'] = $preguntas; // Guardar las preguntas embarajadas en sesión


        function highlightCode($text) {
            // Regex para encontrar etiquetas [img][/img] con una URL dentro
            $imgPattern = '/\[img\](.*?)\[\/img\]/s';
            // Reemplaza las etiquetas con el código HTML necesario para mostrar la imagen
            $text = preg_replace_callback($imgPattern, function($matches) {
                return "<img src='" . htmlspecialchars($matches[1]) . "' style='max-width: 90%; max-height: 30vh; margin-top: 18px;'>"; 
            }, $text);
        
            // A continuación, procesa cualquier otra etiqueta [code][/code] como lo estás haciendo actualmente
            $codePattern = '/\[code\](.*?)\[\/code\]/s'; // Regex para encontrar texto entre marcadores [code]
            return preg_replace_callback($codePattern, function($matches) {
                return "<pre><code class='cpp'>" . htmlspecialchars($matches[1]) . "</code></pre>"; // Utiliza highlight.js
            }, $text);
        }      
        
        
    ?>

    <title><?php echo $tituloTest; ?> | PROXUS Tools</title>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.4.0/styles/default.min.css">
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" async></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.4.0/highlight.min.js"></script>
    <script>
        hljs.highlightAll();
    </script>
    <style>
        pre, pre code {
            border-radius: 8px; /* Ajusta este valor según lo redondeado que desees que sean las esquinas */
        }
    </style>
</head>
<body>
    <?php include 'includes/comun/header.php'; ?>

    <div class="container">
        <h2><?php echo htmlspecialchars($tituloTest); ?></h2>
        
        <form action="logic/procesar_test.php" method="post" style="margin-top: 30px;">
            <input type="hidden" name="total_preguntas" value="<?php echo count($preguntas); ?>">
            <input type="hidden" name="ID_test" value="<?php echo $test_id; ?>">
            <?php $questionNumber = 1; ?>
            <?php foreach ($preguntas as $row): ?>
                <div class="question-card">
                    <div class="question-header">
                        <div class="question-number"><?php echo $questionNumber++; ?></div>
                        <div class="question-text">
                            <?php 
                            $questionText = highlightCode($row['pregunta']);
                            echo $questionText; 
                            ?>
                        </div>
                    </div>
                    <?php
                        $pregunta_id = $row['ID_pregunta'];
                        $stmtOpciones = $db->prepare("SELECT ID_opcion, opcion FROM opciones WHERE opciones.ID_test = ? AND opciones.ID_pregunta = ?");
                        $stmtOpciones->bindValue(1, $test_id, PDO::PARAM_INT);
                        $stmtOpciones->bindValue(2, $pregunta_id, PDO::PARAM_INT);
                        $stmtOpciones->execute();
                        $opciones = $stmtOpciones->fetchAll(PDO::FETCH_ASSOC);
                    ?>
                    <div class="question-options">
                        <?php foreach ($opciones as $row2): ?>
                            <div class="question-option">
                            <label>
                                <input type='radio' name='pregunta_<?php echo $pregunta_id; ?>' value='<?php echo $row2['ID_opcion']; ?>' onclick='toggleRadio(this);' waschecked='false'>
                                <?php
                                $optionText = highlightCode($row2['opcion']);
                                echo $optionText;
                                ?>
                            </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <button type="button" onclick="mostrarConfirmacion()" class="submit-button">Enviar Test</button>
        </form>

        <!-- Pop-up de Confirmación Envío Test -->
        <div id="sendTestPopUp" class="popup-overlay" style="display:none;">
            <div class="popup-content">
                <h2>¿Seguro que ya lo has terminado?</h2>
                <button onclick="closePopup()" class="btn-default">Cancelar</button>
                <button onclick="enviarTest()" class="btn-primary" style="text-decoration: none;">Enviar</button>
            </div>
        </div>
    </div>

    <script>
        // Asegúrate de que Highlight.js se aplique después de que el contenido esté en el DOM.
        document.addEventListener('DOMContentLoaded', (event) => {
            hljs.highlightAll();
        });

        // Agrega un evento para detectar clics en enlaces
        document.addEventListener("click", function(event) {
            // Añade una comprobación para excluir el botón de subir al principio de la página
            if (event.target.tagName === "A" && event.target.id !== "scrollToTopButton") {
                // Pregunta al usuario si desea realizar la acción
                var reiniciar = confirm("¿Deseas reiniciar el test desde cero?");
                if (reiniciar) {
                    // Redirige al usuario al destino del enlace si es necesario
                    var href = event.target.getAttribute("href");
                    if (href) {
                        window.location.href = href;
                    }
                } else {
                    // Cancela la navegación predeterminada si el usuario no desea reiniciar el test
                    event.preventDefault();
                }
            }
        });


        function mostrarConfirmacion() {
            document.getElementById("sendTestPopUp").style.display = "flex";
        }

        function closePopup() {
            document.getElementById("sendTestPopUp").style.display = "none";
        }

        function enviarTest() {
            document.querySelector("form").submit();
        }

        // permite desseleccionar las opciones una vez marcadas
        document.addEventListener('DOMContentLoaded', function() {
            // Selecciona todos los input de tipo radio en el formulario
            const radios = document.querySelectorAll('input[type="radio"]');

            radios.forEach(radio => {
                radio.addEventListener('click', function() {
                    // Verifica si el radio ya estaba marcado
                    if (this.getAttribute('waschecked') === 'true') {
                        this.checked = false;
                        this.setAttribute('waschecked', 'false');
                    } else {
                        // Deselecciona cualquier otro radio marcado en el mismo grupo
                        radios.forEach(el => {
                            if (el !== this && el.name === this.name) {
                                el.setAttribute('waschecked', 'false');
                            }
                        });
                        
                        this.setAttribute('waschecked', 'true');
                    }
                });
            });
        });

    </script>

    <?php include 'includes/comun/footer.php'; ?>
</body>
</html>
