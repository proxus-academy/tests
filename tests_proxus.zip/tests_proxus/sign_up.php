<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <script src="js/sign_up.js"></script>
</head>
<body>
<?php include 'includes/comun/header.php'; ?>
<div class="container">
    <h2>Formulario de Registro</h2>
    <form id="signup-form" action="logic/sign_up_logic.php" method="post" onsubmit="submitForm(event);">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" required>
            <div class="error-message" id="error-nombre"></div>
        </div>
        <div class="form-group">
            <label for="apellidos">Apellidos:</label>
            <input type="text" name="apellidos" id="apellidos" required>
            <div class="error-message" id="error-apellidos"></div>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <div class="error-message" id="error-email"></div>
        </div>
        <div class="form-group">
            <label for="user">Usuario:</label>
            <input type="text" name="user" id="user" required>
            <div class="error-message" id="error-user"></div>
        </div>
        <div class="form-group">
            <label for="psw">Contraseña:</label>
            <input type="password" name="psw" id="psw" required>
            <div class="error-message" id="error-psw"></div>
        </div>
        <div class="form-group">
            <label for="psw-confirm">Confirmar Contraseña:</label>
            <input type="password" name="psw_confirm" id="psw-confirm" required>
            <div class="error-message" id="error-psw-confirm"></div>
        </div>
        <div class="form-group">
            <label for="codigo_registro">Código de Registro:</label>
            <input type="text" name="codigo_registro" id="codigo_registro" required>
            <div class="error-message" id="error-codigo_registro"></div>
        </div>
        <div class="form-group">
            <input type="submit" value="Registrarse">
        </div>
    </form>
</div>

<?php include 'includes/comun/footer.php'; ?>
<script src="js/sign_up.js"></script> <!-- Coloca el script aquí para asegurarte de que se cargue después del HTML -->
</body>
</html>
