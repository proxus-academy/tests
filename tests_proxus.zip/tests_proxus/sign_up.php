<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro | PROXUS Tools</title>
    <script src="js/sign_up.js"></script>
</head>
<body>
<?php include 'includes/comun/header.php'; ?>
<div class="form-container">
    <form id="signup-form" action="logic/sign_up_logic.php" method="post" onsubmit="submitForm(event);" class="form">
        <p class="form-title">Registro</p>
        <p class="message">Por favor, introduce tus datos.</p>
        <label>
            <input type="text" name="nombre" id="nombre" class="input" required>
            <span>Nombre:</span>
            <div class="error-message" id="error-nombre"></div>
        </label>
        <label>
            <input type="text" name="apellidos" id="apellidos" class="input" required>
            <span>Apellidos:</span>
            <div class="error-message" id="error-apellidos"></div>
        </label>
        <label>
            <input type="email" name="email" id="email" class="input" required>
            <span>Email:</span>
            <div class="error-message" id="error-email"></div>
        </label>
        <label>
            <input type="text" name="user" id="user" class="input" required>
            <span>Usuario:</span>
            <div class="error-message" id="error-user"></div>
        </label>
        <label>
            <input type="password" name="psw" id="psw" class="input" required>
            <span>Contraseña:</span>
            <div class="error-message" id="error-psw"></div>
        </label>
        <label>
            <input type="password" name="psw_confirm" id="psw-confirm" class="input" required>
            <span>Confirmar Contraseña:</span>
            <div class="error-message" id="error-psw-confirm"></div>
        </label>
        <label>
            <input type="text" name="codigo_registro" id="codigo_registro" class="input" required>
            <span>Código de Registro:</span>
            <div class="error-message" id="error-codigo_registro"></div>
        </label>
        <input type="submit" value="Registrarse" class="form-submit">
    </form>
</div>

<?php include 'includes/comun/footer.php'; ?>
<script src="js/sign_up.js"></script> 
</body>
</html>
