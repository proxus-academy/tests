<?php include 'includes/comun/config.php'; ?>
<?php
// Incluye la lógica del login
require_once "logic/login_logic.php";

// Define variables y las inicializa con valores vacíos
$user = $psw = "";
$login_err = "";

// Procesa los datos del formulario al enviarlo
if($_SERVER["REQUEST_METHOD"] == "POST"){

    if(empty(trim($_POST["user"])) || empty(trim($_POST["psw"]))){
        $login_err = "Por favor, introduce usuario y contraseña.";
    } else{
        $user = trim($_POST["user"]);
        $psw = trim($_POST["psw"]);

        // Intenta autenticar al usuario
        $result = authenticate($user, $psw);
        if ($result !== true) {
            $login_err = $result;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login | PROXUS Tools</title>
    <link rel="stylesheet" href="path_to_your_stylesheet.css">
</head>
<body>
<?php include 'includes/comun/header.php'; ?>
    <div class="form-container">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="form">
            <h2 class="form-title">Login</h2>
            <?php 
            if(!empty($login_err)){
                echo '<div class="alert">' . $login_err . '</div>';
            }
            ?>
            <label>
                <input type="text" name="user" required="" placeholder="" class="input">
                <span>Usuario</span>
            </label>
            <label>
                <input type="password" name="psw" required="" placeholder="" class="input">
                <span>Contraseña</span>
            </label>
            <input type="submit" value="Login" required="" placeholder="" class="form-submit">
            <p class="link-signin">¿No tienes una cuenta? <a href="sign_up.php">Regístrate ahora</a>.</p>
        </form>
    </div>   
    <?php include 'includes/comun/footer.php'; ?>
</body>
</html>
