<!DOCTYPE html>
<html lang="es">
<head>
    <title>Gráfico de Intentos de Test</title>
    <!-- Incluir Chart.js desde una CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.4.0/styles/default.min.css">
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" async></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.4.0/highlight.min.js"></script>

    <script>
        // mostrar resultados de preguntas
        function toggleQuestions() {
            var container = document.getElementById('questionsContainer');
            container.style.display = container.style.display === 'none' ? 'block' : 'none';
        }

        function toggleRespuestas(element) {
            var respuestas = element.nextElementSibling;
            respuestas.style.display = respuestas.style.display === 'none' ? 'block' : 'none';
        }
    </script>

    <style>
        pre, pre code {
            border-radius: 8px; /* Ajusta este valor según lo redondeado que desees que sean las esquinas */
            white-space: pre-wrap; /* Asegura que el contenido se ajuste dentro del elemento 'pre' */
            word-wrap: break-word; /* Permite que las palabras largas se rompan y pasen a la línea siguiente */
            overflow-wrap: break-word; /* Asegura la ruptura de palabras para evitar el desbordamiento */
            word-break: break-all; /* Asegura que las palabras se rompan en cualquier carácter para evitar el desbordamiento */
        }

        .mathjax, .MathJax, .mjx-chtml {
            overflow-wrap: break-word; /* Permite la ruptura de palabras en fórmulas de MathJax */
            word-wrap: break-word; /* Complementa el manejo de desbordamiento en fórmulas */
        }
    </style>
</head>
<body>
<?php
session_start();

require 'includes/Aplicacion.php';

$db = Aplicacion::getInstance()->getConnection(); // Obtener la conexión usando el patrón Singleton

include 'includes/comun/header.php';?>

<div class="container">
    <?php
    $test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : null;
    $user_id = $_SESSION['ID_usuario'];
    
    if (!$test_id) {
        exit('El ID del test no está definido.');
    }
    
    // Recuperar resultados de la sesión
    $resultados = $_SESSION['resultados_test'] ?? null;
    if (!$resultados) {
        exit('No hay resultados disponibles para mostrar.');
    }

    // Obtener el título y número actualizado de preguntas del test
    $stmt = $db->prepare("SELECT titulo, num_preguntas, resta FROM tests WHERE ID_test = ?");
    $stmt->bindParam(1, $test_id, PDO::PARAM_INT);
    $stmt->execute();
    $row_test = $stmt->fetch(PDO::FETCH_ASSOC);
    $titulo_test = $row_test ? $row_test['titulo'] : "Desconocido";
    $resta_test = $row_test ? $row_test['resta'] : 0;
    $total_preguntas = $row_test ? $row_test['num_preguntas'] : 0;


    $stmt = $db->prepare("SELECT COUNT(*) AS total_intentos, AVG(nota) AS nota_media, SUM(aciertos) AS total_aciertos FROM respuesta_usuario WHERE ID_test = ? AND ID_usuario = ?");
    $stmt->bindParam(1, $test_id, PDO::PARAM_INT);
    $stmt->bindParam(2, $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $row_intentos = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Mostrar resultados
    $total_preguntas = $resultados['total_preguntas'];
    $aciertos = $resultados['aciertos'];
    $fallos = $resultados['fallos'];
    $respuestas_en_blanco = $resultados['respuestas_en_blanco'];
    $nota = $resultados['nota']; 
    
    function highlightCode($text) {
        // Regex para encontrar etiquetas [img][/img] con una URL dentro
        $imgPattern = '/\[img\](.*?)\[\/img\]/s';
        // Reemplaza las etiquetas con el código HTML necesario para mostrar la imagen
        $text = preg_replace_callback($imgPattern, function($matches) {
            return "<img src='" . htmlspecialchars($matches[1]) . "' style='max-width: 90%; max-height: 30vh; margin-top: 18px;'>"; 
        }, $text);
    
        // A continuación, procesa cualquier otra etiqueta [code][/code] como lo estás haciendo actualmente
        $codePattern = '/\[code\](.*?)\[\/code\]/s'; // Regex para encontrar texto entre marcadores [code]
        return preg_replace_callback($codePattern, function($matches) {
            return "<pre><code class='cpp'>" . htmlspecialchars($matches[1]) . "</code></pre>"; // Utiliza highlight.js
        }, $text);
    } 
    ?>
    <h2>Resultados de: '<?php echo $titulo_test; ?>'</h2>
    <div style='text-align: center; margin-top: 25px'>
        <h3>En este intento has obtenido...</h3>
        <table style='min-width: 310px; margin: auto;'>
            <tr>
                <th>Evaluación</th><th>Valor</th>
            </tr>
            <tr>
                <td><img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/conversation2.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> Preguntas totales</td>
                <td style="font-weight: 600;"><?php echo $total_preguntas; ?></td>
            </tr>
            <tr>
                <td><img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/checked.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> Aciertos</td>
                <td style="color: green; font-weight: 600;"><?php echo $aciertos; ?></td>
            </tr>
            <tr>
                <td><img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/cross.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> Fallos</td>
                <td style="color: red; font-weight: 600;"><?php echo $fallos; ?></td>
            </tr>
            <tr>
                <td><img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/file2.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> Respuestas en blanco</td>
                <td style="font-weight: 600;"><?php echo $respuestas_en_blanco; ?></td>
            </tr>
            <tr>
                <td><img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/minus.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> Penalización por respuesta incorrecta</td>
                <td style="font-weight: 600;">-<?php echo $resta_test; ?></td>
            </tr>
            <tr>
                <td><img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/grade2.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> Nota</td>
                <td style="font-weight: 600; background-color: #303030;"><?php echo $nota; ?> / 10</td>
            </tr>
        </table>
    </div>

    <div class="centered-link-container">
        <button id="toggleQuestions" onclick="toggleQuestions()" class="submit-button" style="background-color: royalblue; font-size: 1.2rem;">Mostrar Preguntas</button>
    </div>

    <div id="questionsContainer" style="display:none;">
        <?php
        $questionNumber = 1;
        $preguntas = $_SESSION['preguntas_test'] ?? [];
        foreach ($preguntas as $pregunta) {
            echo "<div class='question-card'>";
            echo "<div class='question-header'>";
            echo "<div class='question-number'>" . $questionNumber++ . "</div>";
            echo "<div class='question-text'>" . highlightCode($pregunta['pregunta']) . "</div>";
            echo "</div>";
            echo "<div class='respuestas'>";

            $pregunta_id = $pregunta['ID_pregunta'];
            $respuestas_usuario = $_SESSION['respuestas'][$pregunta_id] ?? null;
            $opcion_usuario = $respuestas_usuario['opcion_seleccionada'] ?? null;

            $stmtOpciones = $db->prepare("SELECT ID_opcion, opcion, correcta FROM opciones WHERE opciones.ID_test = ? AND opciones.ID_pregunta = ?");
            $stmtOpciones->bindValue(1, $test_id, PDO::PARAM_INT);
            $stmtOpciones->bindValue(2, $pregunta_id, PDO::PARAM_INT);
            $stmtOpciones->execute();
            $opciones = $stmtOpciones->fetchAll(PDO::FETCH_ASSOC);

            foreach ($opciones as $opcion) {
                $color = 'none'; // Color por defecto sin respuesta
                if ($opcion_usuario == $opcion['ID_opcion']) {
                    $color = $opcion['correcta'] ? '#30d143' : '#d13038'; // Cambiar a rojo si la opción es incorrecta
                } else if ($opcion['correcta']) {
                    $color = '#30d143'; // Sólo mostrar verde si la opción es correcta y no fue seleccionada por el usuario
                }
                $texto = highlightCode($opcion['opcion']) ?? 'Texto no disponible';
                echo "<div class='question-option' style='background-color: $color; border-radius: 8px; padding: 3px;'>";
                echo "<label>{$texto}</label>";
                echo "</div>";
            }

            $pregunta_id = $pregunta['ID_pregunta'];
            $detalles_respuesta = $_SESSION['detalles_respuestas'][$pregunta_id] ?? null;

            if ($detalles_respuesta) {
                if (!$detalles_respuesta['respondida']) {
                    echo "<div class='result-info'><span class='status-indicator'></span>Respuesta en blanco, sin cambios en la puntuación.</div>";
                } else if ($detalles_respuesta['correcta']) {
                    echo "<div class='result-info'><span class='status-indicator' style='background-color: green; animation: blinker 1s linear infinite;'></span>Respuesta correcta, suma 1 punto.</div>";
                } else {
                    echo "<div class='result-info'><span class='status-indicator' style='background-color: red; animation: blinker 1s linear infinite;'></span>Respuesta incorrecta, resta " . abs($detalles_respuesta['cambio_puntuacion']) . " puntos.</div>";
                }
            } else {
                echo "<div class='result-info'><span class='status-indicator' style='background-color: whitesmoke; animation: blinker 1s linear infinite;'></span>Respuesta en blanco, 0 puntos.</div>";
            }

            echo "</div>"; // Cierre de respuestas
            echo "</div>"; // Cierre de question-card
        }

        ?>
    </div>


    <?php
    $total_intentos = $row_intentos['total_intentos'] ?? 0;
    $nota_media = $row_intentos['nota_media'] ? round($row_intentos['nota_media'], 2) : 0;
    $total_aciertos = $row_intentos['total_aciertos'] ?? 0;
    $porcentaje_aciertos = ($total_preguntas * $total_intentos) > 0 ? round(($total_aciertos / ($total_preguntas * $total_intentos)) * 100, 2) : 0;

    echo "<div style='text-align: center; margin-top: 25px'>";
    echo "<h3>Estadísticas de todos los intentos</h3>";
    echo "<table style='min-width: 310px; margin: auto;'>";
    echo "<tr><th>Evaluación</th><th>Valor</th></tr>";
    echo "<tr><td>Número total de intentos</td><td>$total_intentos</td></tr>";
    echo "<tr><td>Nota media entre todos los intentos</td><td>$nota_media / 10</td></tr>";
    echo "<tr><td>Porcentaje de aciertos entre todos los intentos</td><td>$porcentaje_aciertos%</td></tr>";
    echo "</table></div>";
    ?>
    <canvas id="intentosChart" width="400" height="200" style="margin-top: 25px;"></canvas>

    <div class="centered-link-container">
        <button id="toggleChartType" class="submit-button" style="background-color: royalblue">Cambiar Gráfico</button>
    </div>

    <div class="centered-link-container">
        <?php if ($titulo_test == "Simulacro Examen" ): ?>
            <a href="realize_test_simulacro_fal.php?id=<?php echo htmlspecialchars($test_id); ?>" class="submit-button">Repetir Test</a>
        <?php else: ?>
            <a href="realize_test.php?id=<?php echo htmlspecialchars($test_id); ?>" class="submit-button">Repetir Test</a>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/comun/footer.php'; ?>

<script>
    // Pasar variables de PHP a JavaScript
    var testId = <?php echo json_encode($test_id); ?>;
    var userId = <?php echo json_encode($user_id); ?>;

    // Script para expandir y colapsar preguntas
    document.addEventListener('DOMContentLoaded', function() {
        const questionCards = document.querySelectorAll('.question-card');
        questionCards.forEach(card => {
            card.addEventListener('click', function() {
                const respuestas = this.querySelector('.respuestas');
                respuestas.style.display = respuestas.style.display === 'none' ? 'block' : 'none';
            });
        });
    });
</script>   
<script src="js/grafica_resultados.js"></script>

</body>
</html>