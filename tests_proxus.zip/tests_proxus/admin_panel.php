<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración | PROXUS Tools</title>
    <style>
        th, td {
            text-align: left;
        }
    </style>

</head>
<body>
    <?php
    session_start();
    require_once "includes/Aplicacion.php";
    if (!isset($_SESSION['loggedin']) || $_SESSION['rol'] !== 'admin') {
        echo "<h1>Acceso denegado: se requiere acceso de administrador</h1>";
    } else {
        ?>
        <?php include 'includes/comun/header.php'; ?>
        <div class="container" style="text-align: left;">
            <h1>Panel de Administración</h1>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Usuario</th>
                        <th>Grado</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $db = Aplicacion::getInstance()->getConnection();

                function loadUserTests($db, $userID) {
                    $sql = "SELECT tests.titulo, respuesta_usuario.nota
                            FROM respuesta_usuario
                            INNER JOIN tests ON respuesta_usuario.ID_test = tests.ID_test
                            WHERE respuesta_usuario.ID_usuario = ?";
                    $stmt = $db->prepare($sql);
                    $stmt->execute([$userID]);
                    $result = "<ul>";
                    while ($test = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $result .= "<li>" . htmlspecialchars($test['titulo']) . " - Nota: " . $test['nota'] . "</li>";
                    }
                    $result .= "</ul>";
                    return $result;
                }

                $sql = "SELECT usuarios.ID_usuario, usuarios.nombre, usuarios.apellidos, usuarios.email, usuarios.user, grados.nombre as grado_nombre
                        FROM usuarios
                        LEFT JOIN grados ON usuarios.ID_grado = grados.ID_grado";
                $stmt = $db->query($sql);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr onclick='toggleDetails(this)'>";
                    echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['apellidos']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['user']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['grado_nombre']) . "</td>";
                    echo "</tr>";
                    echo "<tr class='details'><td colspan='5'>";
                    echo "<div>ID Usuario: " . $row['ID_usuario'] . "</div>";
                    echo loadUserTests($db, $row['ID_usuario']);
                    echo "</td></tr>";
                }

                
                ?>
                </tbody>
            </table>
        </div>

        <?php include 'includes/comun/footer.php'; ?>

        <script>
            function toggleDetails(row) {
                var details = row.nextElementSibling; // Selecciona el tr de detalles siguiente al tr actual
                if (details.style.display === 'none' || !details.style.display) {
                    details.style.display = 'table-row'; // Muestra los detalles
                } else {
                    details.style.display = 'none'; // Oculta los detalles
                }
            }
        </script>
        <?php
    }
    ?>
</body>
</html>
