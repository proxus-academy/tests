<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil | PROXUS Tools</title>
</head>
<body>
    <?php include 'includes/comun/header.php'; ?>
    <?php
    require 'includes/Aplicacion.php';

    if (session_status() == PHP_SESSION_NONE) {
        session_start(); // Asegurar que la sesión se inicia solo si no está activa
    }

    // Verificar si el usuario ha iniciado sesión
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        header("Location: login.php"); // Si no ha iniciado sesión, redirigir a la página de inicio de sesión
        exit();
    }
    
    $db = Aplicacion::getInstance()->getConnection(); // Obtener la conexión a través del Singleton

    $user_id = $_SESSION["ID_usuario"]; // Obtener el ID de usuario de la sesión

    /**
     * Obtiene la información del usuario de la base de datos.
     *
     * @param PDO $db La conexión a la base de datos.
     * @param int $userID El ID del usuario.
     * @return array|null Los datos del usuario o null si no se encuentra.
     */
    function getUserInfo($db, $userID) {
        if (empty($userID)) {
            return null;
        }

        $stmt = $db->prepare("SELECT * FROM usuarios WHERE ID_usuario = ?");
        $stmt->bindParam(1, $userID, PDO::PARAM_INT);
        $stmt->execute();
        $userInfo = $stmt->fetch(PDO::FETCH_ASSOC);

        return $userInfo ? $userInfo : null;
    }

    // Asumiendo que se ha iniciado sesión y el ID del usuario está almacenado en la sesión
    $userID = $_SESSION['ID_usuario'] ?? null;
    $userInfo = getUserInfo($db, $userID);
    ?>

    <div class="container" style="text-align: center;">
        <h1>Perfil de Usuario</h1>
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($userInfo['nombre'] . ' ' . $userInfo['apellidos']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($userInfo['email']); ?></p>
        
        <section style="display:flex; flex-direction: column; gap: 20px; align-items: center; justify-content: center; margin-top: 60px;">
        <a href="user_menu_tests.php">
            <button class="learn-more">
                <span class="circle" aria-hidden="true">
                    <span class="icon arrow"></span>
                </span>
                <span class="button-text">Tests Realizados</span>
            </button>
        </a>
        
        <a href="#" onclick="showPopup(); return false;">
            <button class="learn-more">
                <span class="circle" aria-hidden="true">
                    <span class="icon arrow"></span>
                </span>
                <span class="button-text">Cerrar Sesión</span>
            </button>
        </a>
        </section>

    </div>

    <!-- Pop-up de Confirmación -->
    <div id="confirmationPopup" class="popup-overlay" style="display:none;">
        <div class="popup-content">
            <h2>¿Estás seguro de que quieres salir?</h2>
            <button onclick="closePopup()" class="btn-default">Cancelar</button>
            <a href="logic/logout.php" class="btn-primary" style="text-decoration: none;">Salir</a>
        </div>
    </div>

    <script>
        function showPopup() {
            document.getElementById('confirmationPopup').style.display = 'flex'; // Cambio de 'block' a 'flex'
        }

        function closePopup() {
            document.getElementById('confirmationPopup').style.display = 'none';
        }
    </script>

    <?php include 'includes/comun/footer.php'; ?>
</body>
</html>
