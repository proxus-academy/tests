<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido | PROXUS Tools</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Asegúrate de ajustar la ruta al CSS según tu estructura -->
</head>
<body>
    <?php include 'includes/comun/header.php'; ?>

    <div class="container" style="text-align: center;">
        <h1 style="margin-top: 75px;">¡Bienvenido/a!</h1>
        <p>Te has registrado correctamente.</p>
        <a href="login.php" class="submit-button" style="text-decoration: none;">Iniciar Sesión</a> <!-- Asegúrate de que la ruta al login.php es correcta -->
    </div>

    <?php include 'includes/comun/footer.php'; ?>
</body>
</html>
