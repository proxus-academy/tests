<?php include 'includes/comun/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="description">
    <title>Tests | PROXUS Tools</title>
</head>
<body>
    <?php include 'includes/comun/header.php'; ?>
    <?php include 'logic/get_tests.php'; ?>

    <div class="container">
        <h2>Tests Disponibles</h2>
        <div class="separator-gray"></div>
        <!-- <div class="info-section"></div> -->

        <?php if (!empty($tests)): ?>
            <?php foreach ($tests as $row): ?>
                <div class="card">
                    <div class="card2">
                        <h3><?php echo htmlspecialchars($row["titulo"]); ?></h3>
                        <p>Asignatura: <?php echo htmlspecialchars($row["asignatura_nombre"]); ?></p>
                        <p>Intentos realizados: <?php echo htmlspecialchars($row["numero_intentos"]); ?></p>
                        <!-- Comprobar si el título del test es 'Simulacro Examen' y la asignatura es 'Fundamentos de Algoritmia' -->
                        <?php if ($row["titulo"] == "Simulacro Examen" && $row["asignatura_nombre"] == "Fundamentos de Algoritmia"): ?>
                            <a href="realize_test_simulacro_fal.php?id=<?php echo htmlspecialchars($row['ID_test']); ?>" class="buttonT">Realizar Test</a>
                        <?php else: ?>
                            <a href="realize_test.php?id=<?php echo htmlspecialchars($row['ID_test']); ?>" class="buttonT">Realizar Test</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align: center; margin-top: 40px;">No hay tests disponibles para este usuario.</p>
        <?php endif; ?>
    </div>

    <?php include 'includes/comun/footer.php'; ?>
</body>
</html>
