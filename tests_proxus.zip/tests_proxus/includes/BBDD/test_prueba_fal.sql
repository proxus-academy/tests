CREATE DATABASE IF NOT EXISTS flexam;
USE flexam;

CREATE TABLE `usuarios` (
  `ID_usuario` INT AUTO_INCREMENT PRIMARY KEY,
  `user` VARCHAR(255) NOT NULL,
  `psw` VARCHAR(255) NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  `apellidos` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `ID_universidad` INT,
  `ID_grado` INT,
  `rol` VARCHAR(255) NOT NULL
);

CREATE TABLE `universidades` (
  `ID_universidad` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(255) NOT NULL,
  `abreviatura` VARCHAR(5) NOT NULL,
  `ciudad` VARCHAR(255) NOT NULL
);

CREATE TABLE `grados` (
  `ID_grado` INT AUTO_INCREMENT PRIMARY KEY,
  `ID_universidad` INT NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  FOREIGN KEY (`ID_universidad`) REFERENCES `universidades`(`ID_universidad`)
);

CREATE TABLE `asignaturas` (
  `ID_asignatura` INT AUTO_INCREMENT PRIMARY KEY,
  `ID_universidad` INT NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  `abreviatura` VARCHAR(5) NOT NULL,
  FOREIGN KEY (`ID_universidad`) REFERENCES `universidades`(`ID_universidad`)
);

CREATE TABLE `grado_asignatura` (
  `ID_grado` INT NOT NULL,
  `ID_asignatura` INT NOT NULL,
  PRIMARY KEY (`ID_grado`, `ID_asignatura`),
  FOREIGN KEY (`ID_grado`) REFERENCES `grados`(`ID_grado`),
  FOREIGN KEY (`ID_asignatura`) REFERENCES `asignaturas`(`ID_asignatura`)
);

CREATE TABLE `tests` (
  `ID_test` INT AUTO_INCREMENT PRIMARY KEY,
  `titulo` VARCHAR(255) NOT NULL,
  `ID_usuario` INT NOT NULL,
  `num_preguntas` INT NOT NULL,
  `es_publico` BOOLEAN NOT NULL,
  `es_anonimo` BOOLEAN NOT NULL,
  `resta` DECIMAL(5,3),
  FOREIGN KEY (`ID_usuario`) REFERENCES `usuarios`(`ID_usuario`)
);

CREATE TABLE `test_asignatura` (
  `ID_test` INT NOT NULL,
  `ID_universidad` INT NOT NULL,
  `ID_asignatura` INT NOT NULL,
  PRIMARY KEY (`ID_test`, `ID_universidad`, `ID_asignatura`),
  FOREIGN KEY (`ID_test`) REFERENCES `tests`(`ID_test`),
  FOREIGN KEY (`ID_universidad`) REFERENCES `universidades`(`ID_universidad`),
  FOREIGN KEY (`ID_asignatura`) REFERENCES `asignaturas`(`ID_asignatura`)
);

CREATE TABLE `preguntas` (
  `ID_pregunta` INT AUTO_INCREMENT PRIMARY KEY,
  `ID_test` INT NOT NULL,
  `pregunta` TEXT NOT NULL,
  FOREIGN KEY (`ID_test`) REFERENCES `tests`(`ID_test`)
);

CREATE TABLE `opciones` (
  `ID_test` INT NOT NULL,
  `ID_pregunta` INT NOT NULL,
  `ID_opcion` INT NOT NULL,
  `opcion` TEXT NOT NULL,
  `correcta` BOOLEAN NOT NULL,
  PRIMARY KEY (`ID_test`, `ID_pregunta`, `ID_opcion`),
  FOREIGN KEY (`ID_test`, `ID_pregunta`) REFERENCES `preguntas`(`ID_test`, `ID_pregunta`)
);

CREATE TABLE `respuesta_usuario` (
  `ID_test` INT NOT NULL,
  `ID_usuario` INT NOT NULL,
  `ID_intento` INT AUTO_INCREMENT PRIMARY KEY,
  `nota` DECIMAL(5,2) NOT NULL,
  `aciertos` INT NOT NULL,
  `fecha` TIMESTAMP NOT NULL,
  FOREIGN KEY (`ID_test`) REFERENCES `tests`(`ID_test`),
  FOREIGN KEY (`ID_usuario`) REFERENCES `usuarios`(`ID_usuario`)
);

CREATE TABLE `codigos_registro` (
  `codigo` CHAR(8) PRIMARY KEY,
  `usado` BOOLEAN NOT NULL DEFAULT FALSE,
  `ID_universidad` INT NOT NULL DEFAULT 1,
  `ID_grado` INT NOT NULL DEFAULT 1
);

/* fal */
INSERT INTO `codigos_registro` (`codigo`, `usado`) VALUES
('28L09TF3', FALSE),
('3IETJPSW', FALSE),
('3W4ZYZ4J', FALSE),
('7QMT2E79', FALSE),
('7SD7PUB7', FALSE),
('860DFRO8', FALSE),
('8OQ0FC59', FALSE),
('8U4AZKPM', FALSE),
('CHNAF4ET', FALSE),
('E9EFPRDI', FALSE),
('EAK7FXLC', FALSE),
('FA5KFIVK', FALSE),
('GG838E38', FALSE),
('I6IT2PW3', FALSE),
('ITZS9QB9', FALSE),
('KJX95BDH', FALSE),
('MJQEHL5K', FALSE),
('Q025HNT8', FALSE),
('S40OT9AI', FALSE),
('Z83CZPBL', FALSE);

/* Friends and family */
INSERT INTO `codigos_registro` (`codigo`, `usado`, `ID_universidad`, `ID_grado`) VALUES
('KPLYVUHY', FALSE, 1, 2),
('VMEWJUSO', FALSE, 1, 2),
('XFJNJPDO', FALSE, 1, 2),
('EBYCXGVQ', FALSE, 1, 2),
('VNFPFFNL', FALSE, 1, 2),
('CCPZSCNK', FALSE, 1, 2),
('FHURNCTJ', FALSE, 1, 2),
('QEOAEOER', FALSE, 1, 2),
('HFPEFWAN', FALSE, 1, 2),
('KYTWUXGV', FALSE, 1, 2),
('LRCZIAYN', FALSE, 1, 2),
('LILNBHCB', FALSE, 1, 2),
('TFRILTYH', FALSE, 1, 2),
('WSMKUELH', FALSE, 1, 2),
('DPGZBNXW', FALSE, 1, 2),
('GSRBPBYZ', FALSE, 1, 2),
('EXHQUIGL', FALSE, 1, 2),
('NMFUWOLO', FALSE, 1, 2),
('HLRVITDW', FALSE, 1, 2),
('MBFHWITO', FALSE, 1, 2);

/* mdl1 */
INSERT INTO `codigos_registro` (`codigo`, `usado`, `ID_universidad`, `ID_grado`) VALUES
('ZUSHOGAY', FALSE, 1, 3),
('FJUOXCTP', FALSE, 1, 3),
('QQLKHGCW', FALSE, 1, 3),
('JIFEGAFG', FALSE, 1, 3),
('BLPSRLZW', FALSE, 1, 3),
('MYISRZQU', FALSE, 1, 3),
('HJKCNORV', FALSE, 1, 3),
('AVGFHXMY', FALSE, 1, 3),
('ZLROKZHT', FALSE, 1, 3),
('SGELNVKX', FALSE, 1, 3),
('SJDZEONO', FALSE, 1, 3),
('FCNJVSPT', FALSE, 1, 3),
('VXYLUXDU', FALSE, 1, 3),
('RXFSUGVI', FALSE, 1, 3),
('DNUYBGVF', FALSE, 1, 3),
('WKGWFRWK', FALSE, 1, 3),
('AORHCDHQ', FALSE, 1, 3),
('WPHHHWEQ', FALSE, 1, 3),
('DGRYDDBD', FALSE, 1, 3),
('HQDDKQRU', FALSE, 1, 3);

/* mdl2 */
INSERT INTO `codigos_registro` (`codigo`, `usado`, `ID_universidad`, `ID_grado`) VALUES
('VSXIIBRV', FALSE, 1, 4),
('RGRKIHFB', FALSE, 1, 4),
('ZXLQMRHH', FALSE, 1, 4),
('NPZCBFIZ', FALSE, 1, 4),
('WXRQEBDK', FALSE, 1, 4),
('CPQWPAKJ', FALSE, 1, 4),
('AKPCSFVH', FALSE, 1, 4),
('CHKMLRSM', FALSE, 1, 4),
('QMEYBKXK', FALSE, 1, 4),
('ZMPCCVBZ', FALSE, 1, 4),
('CPKTUEWA', FALSE, 1, 4),
('CIAMYURS', FALSE, 1, 4),
('GCNZWJVL', FALSE, 1, 4),
('IJOEKQST', FALSE, 1, 4),
('ZZWUZGKI', FALSE, 1, 4),
('GQFSFUSW', FALSE, 1, 4),
('JFJCZZWJ', FALSE, 1, 4),
('UKSVOOJD', FALSE, 1, 4),
('QQOXOSDQ', FALSE, 1, 4),
('BDYQQFSD', FALSE, 1, 4);


ALTER TABLE `usuarios` ADD FOREIGN KEY (`ID_universidad`) REFERENCES `universidades` (`ID_universidad`);
ALTER TABLE `usuarios` ADD FOREIGN KEY (`ID_grado`) REFERENCES `grados` (`ID_grado`);

  /* Insercion de datos */
-- Insertando universidades
INSERT INTO `universidades` (`nombre`, `abreviatura`, `ciudad`) VALUES
('Universidad Complutense de Madrid', 'UCM', 'Madrid');

-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Grados en la UCM
INSERT INTO `grados` (`ID_universidad`, `nombre`) VALUES
(@ucm_id, 'SPEEDRUN FAL'),
(@ucm_id, 'PROXUS Friends and Family'),
(@ucm_id, 'SPEEDRUN MDL1'),
(@ucm_id, 'SPEEDRUN MDL2');

INSERT INTO usuarios (user, psw, nombre, apellidos, email, ID_universidad, ID_grado, rol) VALUES
('flex', '$2y$10$ju5ai6teON3lyG45i0pk4e1ijKD0TiOazMnKN2RIFuQnHD8Z/zhwq', 'Flex', 'Exam', 'flex@exam.com', 1, 1, 'estudiante'),
('mdl2', '$2y$10$gfjefQBOmJPsWm6FeWlvqe5h0IUscEGUe.FwarmQomeLtV7TF5Hau', 'MDL2', 'Prueba', 'mdl2@exam.com', 1, 4, 'estudiante'),
('mdl1', '$2y$10$.VZnN7pRtVl8kmiIDvpkWOYjPncCyrqWv5KRiAV2QeN0D6fpRZ.wm', 'MDL1', 'Prueba', 'mdl1@exam.com', 1, 3, 'estudiante'),
('ff', '$2y$10$reIeBltGnH1mOVnqJ0Rxiu6wx8tipHkkEs5yGuAO4tEQKwqVDfLw.', 'FF', 'Prueba', 'ff@exam.com', 1, 2, 'estudiante'),
('proxus', '$2y$10$rRjhZX8lrBP2BAlg66.VgeewVn78jv22W6geqK.vOmFvNd17KgvSm', 'Admin', 'User', 'admin@user.com', NULL, NULL, 'admin');

-- Asignaturas comunes y específicas de los grados en UCM
INSERT INTO `asignaturas` (`ID_universidad`, `nombre`, `abreviatura`) VALUES
(@ucm_id, 'Matemática Discreta y Lógica 1', 'MDL1'),
(@ucm_id, 'Matemática Discreta y Lógica 2', 'MDL2'),
(@ucm_id, 'Auditoría Informática 2', 'AI2'),
(@ucm_id, 'Investigación Comercial', 'IC'),
(@ucm_id, 'Dirección de Recursos Humanos', 'RRHH'),
(@ucm_id, 'Fundamentos de Algoritmia', 'FAL');

-- Obtener ID de los grados de SPEEDRUN FAL
SET @speedrun_fal_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'SPEEDRUN FAL' AND `ID_universidad` = @ucm_id);
SET @speedrun_mdl1_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'SPEEDRUN MDL1' AND `ID_universidad` = @ucm_id);
SET @speedrun_mdl2_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'SPEEDRUN MDL2' AND `ID_universidad` = @ucm_id);
SET @speedrun_ff_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'PROXUS Friends and Family' AND `ID_universidad` = @ucm_id);

-- Obtener ID de las asignaturas
SET @mdl1_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MDL1' AND `ID_universidad` = @ucm_id);
SET @mdl2_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MDL2' AND `ID_universidad` = @ucm_id);
SET @ai2_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'AI2' AND `ID_universidad` = @ucm_id);
SET @ic_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'IC' AND `ID_universidad` = @ucm_id);
SET @rrhh_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'RRHH' AND `ID_universidad` = @ucm_id);
SET @fal_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'FAL' AND `ID_universidad` = @ucm_id);

-- Asociar grados y asignaturas en SPEEDRUN FAL
INSERT INTO `grado_asignatura` (`ID_grado`, `ID_asignatura`) VALUES
(@speedrun_fal_id, @fal_id),
(@speedrun_mdl1_id, @mdl1_id),
(@speedrun_mdl2_id, @mdl2_id),
(@speedrun_ff_id, @ai2_id),
(@speedrun_ff_id, @ic_id),
(@speedrun_ff_id, @rrhh_id);

-- --------------------------------------------------------------------------------------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------


-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Obtener ID de FAL
SET @fal_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'FAL' AND `ID_universidad` = @ucm_id);

-- Insertar el test 'Prueba 1 FAL'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Banco de Preguntas | FAL', 1, 31, TRUE, FALSE, 0.333);
SET @test_fal_id := LAST_INSERT_ID();  -- Obtener el ID del test recién insertado

-- Asociar el test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@test_fal_id, @ucm_id, @fal_id);

-- Pregunta 1: Complejidad de un algoritmo que verifica un vector decreciente
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo que comprueba si un vector de \\( n \\) elementos es estrictamente decreciente tiene complejidad en el caso mejor:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(1)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 2: Coste peor caso del algoritmo de ordenación por inserción
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El coste en el caso peor del algoritmo de ordenación por inserción sobre un vector de \\( n \\) elementos está en:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(2^n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Theta(n^2)\\)", TRUE);

-- Pregunta 3: Complejidad de inserción en vector no ordenado
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo para insertar un elemento en un vector no necesariamente ordenado sin elementos repetidos (de forma que siga sin tener elementos repetidos) tiene complejidad en el caso peor (la más ajustada):");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Theta(n \\log n)\\)", FALSE);

-- Pregunta 4: Búsqueda del mínimo en vector ordenado
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo que busca el mínimo en un vector ordenado de n elementos tiene complejidad en el caso peor:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 5: Complejidad de un algoritmo anidado
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int a = 0;\nfor (int i = 0; i < n+20; ++i)\n   for (int j = m+30; j >= 0; --j)\n    --a;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n^m)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(\\max(n, m))\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int a = 0;\nfor (int i = 1; i < n; i *= 3)\n    --a;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> \\(\\{ 0 \\leq n \\leq \\text{long}(v) \\}\\)\n\n[code]fun xxx (int v[], int n, int x) dev int r[/code]\n\n\\(\\{ r = \\# u : 0 \\leq u < n : v[u] < x \\}\\) <br>y teniendo en cuenta que estamos considerando los n primeros elementos del vector, indica qué afirmación es correcta con respecto a ella.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) La postcondición está mal definida cuando n=0.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) El valor de r es la posición en el vector del último elemento menor que x.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El valor de r es la posición en el vector del primer elemento menor que x.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> \\(\\{ 0 < n \\leq \\text{longitud}(v) \\}\\)\n\n[code]fun xxx (int v[], int n) dev int r[/code]\n\n\\(\\{ r = \\max u : 0 \\leq u < n \\land u \\mod 2 = 0 : v[u] \\}\\) <br>y teniendo en cuenta que estamos considerando los n primeros elementos del vector, indica qué afirmación es correcta con respecto a ella.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El valor de r es la posición más a la derecha que contiene un elemento par.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) El valor de r es el máximo de los elementos pares del vector.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El valor de r es el máximo de los elementos del vector que se encuentran en posiciones pares.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 9
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la siguiente especificación y valores de los parámetros de entrada, indica cuál es el valor del resultado: <br> \\(\\{ 0 \\leq n \\leq \\text{longitud}(v) \\}\\)\n\n[code]fun xxx (int v[], int n) dev int r[/code]\n\n\\(\\{ r = \\# u : 0 \\leq u < n : \\text{suma}(v,0,u) < \\text{suma}(v,u+1,n) \\}\\) <br>siendo<br>\\(\\text{suma}(v,c,f) = \\sum z : c \\leq z < f : v[z]\\) <br>Datos de entrada: n=5, v=[1,-1,1,-1,1]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) r = 3.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) r = 0.", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) r = 2.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 10
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica si la siguiente afirmación es verdadera o falsa: <br> \\(2n + n^{10} \\in \\Omega(n^{10})\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Verdadero", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Falso", FALSE);

-- Pregunta 11
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes afirmaciones es incorrecta:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n) \\subset \\Theta(2^n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(\\sqrt{n}) \\subset \\Theta(n^3)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Omega(1) \\subset \\Omega(n^2)\\)", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Omega(n) \\subset \\Omega(2n)\\)", FALSE);

-- Pregunta 12
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El siguiente predicado es más débil que cualquier otro predicado: <br> \\(x > 0 \\lor x < 0\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Verdadero", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Falso", TRUE);

-- Pregunta 13
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El siguiente predicado es más débil que cualquier otro predicado: <br> \\(\\text{false} \\rightarrow \\text{true}\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Falso", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Verdadero", TRUE);

-- Pregunta 14
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dado un vector v con N elementos, ¿qué representa la siguiente expresión? <br> \\(\\max p, q : 0 \\leq p \\leq q \\leq N \\) \\( \\land P(v, p, q) : q - p\\) <br>siendo <br>\\(P(v, p, q) = \\forall l : p \\leq l < q \\) \\(: v[l] \\geq 0 \\land v[l] \\mod 2 = 0\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El número de posiciones del vector cuyos elementos cumplen la propiedad de ser pares.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) La resta de las dos mayores posiciones del vector cuyos elementos cumplen la propiedad de ser pares.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El máximo número de posiciones consecutivas cuyos elementos cumplen la propiedad de ser pares.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 15
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál es la precondición más débil: <br> {\\({???}\\)} <br>  \\(x = y;\\) <br>\t\\(y = x;\\) <br>\t{\\({x == 3 \\land y == 4}\\)}");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) y \\(\\neq\\) x", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) y == 3 \\(\\land\\) x == 4", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) true", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 16
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "¿Cuál de estas afirmaciones es correcta? (x e y variables de tipo entero).");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) {x > 0 \\(\\land\\) y < 0} nada {x + y > 0}", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) {x + y > 0} nada {x > 0}", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) {x > 0 \\(\\land\\) y > 0} nada {x / y > 0}", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);


-- Pregunta 17
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál es la afirmación correcta acerca de este algoritmo de búsqueda binaria en el que la precondición es \\(0 \\leq c \\leq f + 1 \\leq \\text{longitud}(v)\\): [code]int f(int v[], int x, int c, int f) {\n    int resultado;\n    if (c > f)\n        {resultado = c-1;}\n    else\n    {\n        int m = (c+f)/2;\n        if (v[m] > x)\n          {resultado = f(v, x, c, m);}\n        else\n          {resultado = f(v, x, m, f);}\n    }\n    return resultado;\n}[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Sólo termina si c < f.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Nunca termina.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Siempre termina.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", TRUE);

-- Pregunta 18
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "La generalización es una técnica que se utiliza para:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Todas son correctas", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Diseñar algoritmos recursivos.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Mejorar la eficiencia de los algoritmos recursivos.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Disponer de funciones más generales que la que se deseaba.", FALSE);

-- Pregunta 19
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "En los algoritmos recursivos en los que se reduce el tamaño del problema por sustracción: <br> \\(T(n) = c_0 \\text{ si } 0 \\leq n \\leq n_0\\) <br> \\(T(n) = aT(n - b) + cn^k \\text{ si } n > n_0\\):");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Para que sea polinómico es necesario que b>a.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Si a = 1 el coste es logarítmico.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Si a>1, es siempre exponencial por muy grande que sea b.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 20
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dado el siguiente algoritmo que calcula la raíz cuadrada entera de un número dado x: <br> {\\(x \\geq 0\\)}[code]r=0;\nwhile ((r+1)*(r+1)<=x){\n  r=r+1; \n}\n[/code]{\\(r >= 0 \\land r*r \\leq x < (r + 1)*(r + 1)\\)} <br> Indica cuáles de las siguientes funciones de cota no demuestra la terminación del bucle:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) x - r*r", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) x - r", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) x - r*(r + 1)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) r", TRUE);

-- Pregunta 21
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes es una función de cota para este bucle: [code]int i=0; bool encontrado=false;\nwhile (i<n && !encontrado){\n    if (v[i]>0)\n    {encontrado=true;}\n    else\n    {i=i+1;}\n}[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) n - i", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) i", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) n - i + 1", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de ellas.", TRUE);

-- Pregunta 22
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "En un problema de maximización resuelto con vuelta atrás la cota optimista o beneficio estimado:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) siempre puede ser el valor de la solución parcial.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) puede ser 0 si los beneficios son positivos.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) debe ser cota inferior de la mejor solución alcanzable.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", TRUE);

-- Pregunta 23
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El coste de la poda de optimalidad puede ser tan elevado que no compense la poda conseguida.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Verdadero", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Falso", FALSE);

-- Pregunta 24
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> {\\(v.size \\geq 0\\)}\n\n[code]fun xxx(vector<int> v) dev int r[/code]\n\n{\\(r = \\max p, q : 0 \\leq p \\leq q \\leq v.size \\land \\forall i\\) \\(: p \\leq i < q : v[i] = 0 : q - p\\)}\n<br>y el vector de entrada v = [5, 4, 0, 4, 3, 0, 0, 0, 0, 5, 3, 0, 0, 5], ¿cuál es el valor de r según la especificación?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) r = 7.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) r = 0.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) r = 4.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 25
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo que busca el máximo en un vector ordenado de n elementos tiene complejidad en el caso peor:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(1)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 26
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int c = 0;\nfor (int i = 1; i < n; i *= 2)\nfor (int j = 0; j < m+2; ++j)\nc += 4;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(m \\log n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(nm)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 27
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dado un vector a de n enteros, con n ≥ 1, y una variable booleana b, el predicado \\(b = \\exists w : 0 \\leq w < n \\) \\( : (\\exists k : 0 \\leq k : a[w] = 2k + 1)\\)<br> significa que la variable b toma el valor cierto si y sólo si:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Hay al menos una posición en el vector que contiene un número impar positivo.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Nunca toma el valor cierto.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Todas las posiciones del vector son impares.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 28
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> {\\(a.size \\geq 0\\)}\n\n[code]fun contarPares(vector<int> a)\n  dev int c\n\n[/code]{\\(c = \\#i : 0 \\leq i < a.\\text{size} : a[i] \\mod 2 = 0\\)}<br><br> y el siguiente algoritmo: [code]int contarPares(vector<int> const& a) {\nint c=0; int k=-1;\nwhile (k<a.size()-1)\n{\nif (a[k+1] % 2 == 0) {c=c+1;}\nk=k+1;\n}\nreturn c;\n}[/code] indica si el algoritmo es correcto con respecto a la especificación y en tal caso cuál es el invariante que permite demostrar la corrección del bucle.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Es correcto con invariante {−1 ≤ k < a.size ∧ c = #i : 0 ≤ i < k : a[i] % 2 = 0}.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Es correcto con invariante {−1 ≤ k < a.size ∧ c = #i : 0 ≤ i ≤ k : a[i] % 2 = 0}.", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) Es correcto con invariante {−1 ≤ k ≤ a.size ∧ c = #i : 0 ≤ i < n : a[i] % 2 = 0}.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 29
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes afirmaciones sobre el algoritmo quicksort (ordenación rápida) es falsa:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Si los valores del vector están ordenados en orden creciente tiene un orden de complejidad cuadrático respecto al tamaño del vector.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Si los valores del vector presentan una distribución uniforme en un intervalo de valores, el algoritmo tiene una complejidad n log n siendo n el número de elementos del vector.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El algoritmo tiene una complejidad n log n siendo n el número de elementos del vector tanto en el caso peor como en el caso medio.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) El algoritmo tiene una complejidad cuadrática respecto al número de elementos del vector en el caso peor.", FALSE);

-- Pregunta 30
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dos algoritmos que tienen el mismo orden de complejidad:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Se comportan de forma semejante para tamaños de entrada grandes.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Se comportan de forma semejante para tamaños de entrada pequeños.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Tardan exactamente el mismo tiempo en ejecutarse.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Todas de las anteriores.", FALSE);

-- Pregunta 31
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de los siguientes es un requisito imprescindible para poder utilizar el algoritmo de la búsqueda binaria sobre un vector:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El vector debe tener al menos un elemento.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Los elementos del vector deben ser números enteros.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Los valores del vector deben estar ordenados (según un orden bien definido).", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Todas las anteriores.", FALSE);

-- Pregunta 32
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica qué función de cota utilizarías para probar la terminación del siguiente bucle: [code]int k = 0;\nint N = 100; \nfor (int i = N-1; i > -N; --i) ++k;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(f(i, N) = i\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(f(i, N) = i + N\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(f(i, N) = i - N\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(f(i, N) = N - i\\)", FALSE);

-- Pregunta 33
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica el coste de un algoritmo cuya recurrencia es: [code]T(n) = {\n 	c0 si n == 0\n 	T(n - 1) + n si n > 0\n       }[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n \\log n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 34
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: \\({ n = \\text{longitud}(v) }\\) [code]fun foo(int v[], int n) dev int r[/code] \\({ r = \\max p, q : 0 \\leq p \\leq q \\leq n \\land \\forall i : p \\leq i < q - 1 : v[i + 1] = v[i] + 1 : q - p }\\) y el vector de entrada v = [5, 1, 2, 4, 6, 7, 8, 9, 10, 12, 11, 0], ¿cuál es el valor de r según la especificación?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) r = 7", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) r = 5", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) r = 4", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 35
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Para calcular el mínimo de los valores de un vector de tamaño n que contiene números enteros pertenecientes al intervalo [1..1000]:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Se puede calcular utilizando divide y vencerás con una complejidad \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Un algoritmo eficiente ordena el vector y obtiene el elemento en la posición 0", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Si el vector es vacío el mínimo es siempre 0", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) La mejor complejidad que se puede obtener es del orden \\(\\Theta(n)\\)", TRUE);

-- Pregunta 36
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int c = 0;\nfor (int j = 0; j < n+2; j+=2)\n    for (int i = 1; i < m; i *= 3)\n        c += 4;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(m \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n \\log m)\\)", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 37
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "¿Cuál de los siguientes predicados especifica que un vector a de n elementos está ordenado de forma creciente?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\forall w : 0 \\leq w < n - 1 : a[w] \\leq a[w + 1]\\)", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\forall w : 0 \\leq w < n : a[w] \\leq a[w + 1]\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\exists w : 0 \\leq w < n - 1 : a[w] \\leq a[w + 1]\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 38
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las propiedades es un invariante del siguiente bucle: [code]int y = 1;\nint j = n;\nwhile (j > 0) {\n  y = y * x;\n  j--;\n}[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\( y = x^{j}\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\( 0 < j \\leq n\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\( y = x^{n-j}\\)", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna", FALSE);

-- Pregunta 39
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica el coste de un algoritmo cuya recurrencia es: [code]T(n) = {\n 	c0 si n = 0\n 	2T(n/2) + n si n > 0\n       }[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n \\log n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna", FALSE);

-- Pregunta 40
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dados dos algoritmos A y B con órdenes de complejidad \\(\\Theta(f(n))\\) y \\(\\Theta(g(n))\\) respectivamente, si \\(\\Theta(f(n)) \\subset \\Theta(g(n))\\):");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El algoritmo A siempre tiene un tiempo de ejecución menor que el algoritmo B independientemente del tamaño de entrada", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) El algoritmo A tiene un tiempo de ejecución menor que el algoritmo B solo para tamaños de entrada grandes", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El tamaño de entrada a partir del cual el algoritmo A tiene un tiempo de ejecución menor que el algoritmo B depende de la constante multiplicativa del algoritmo", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) El algoritmo A siempre tiene un tiempo de ejecución mayor que el algoritmo B, independientemente del tamaño de entrada", FALSE);

-- Pregunta 41
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes respuestas no es correcta respecto al algoritmo de búsqueda binaria que comprueba si un valor se encuentra en una secuencia de valores.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El algoritmo de búsqueda binaria solo se puede aplicar sobre secuencias de valores ordenadas.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Si la secuencia de valores no está ordenada es más eficiente ordenarla y buscar el elemento con búsqueda binaria que realizar una búsqueda secuencial.", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) La búsqueda binaria sobre un vector vacío siempre devuelve como resultado false.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) La búsqueda binaria en un vector ordenado siempre es más eficiente que la búsqueda secuencial para secuencias de valores grandes.", FALSE);

-- Pregunta 42
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El orden en el que se recorren las ramas del árbol de exploración en un algoritmo de vuelta atrás influye en las podas que se realizan y por lo tanto en el tiempo de ejecución del algoritmo:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Siempre.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Nunca.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Solo podría influir en los problemas de optimización.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Nunca podría influir en los problemas de optimización.", FALSE);

-- Pregunta 43
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo que obtiene las combinaciones de k elementos que pueden formarse con n elementos diferentes utilizando la técnica de vuelta atrás tiene complejidad:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n * k)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(k^n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Theta(n^k)\\)", TRUE);

-- Pregunta 44
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Si la precondición de un algoritmo es false, ¿qué afirmación es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Cualquier postcondición será válida.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Si se ejecuta el algoritmo dicha ejecución no terminará.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Si se ejecuta el algoritmo se producirá un error en tiempo de ejecución.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna postcondición será válida.", FALSE);

-- Pregunta 45
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes afirmaciones es incorrecta:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n) \\subset \\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(2^n) \\subset \\Theta(n^2)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(2 \\in \\Theta(1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(n \\log(n) \\in \\Theta(n^2)\\)", FALSE);

-- Pregunta 46
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int c = 0;\nfor (int i = 0; i < n; i += 2) c += 1;\nfor (int j = 0; j < n; ++j) c += 3;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 47
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "¿Qué significa el siguiente predicado para un vector no vacío de naturales? \\(\\forall i : 1 \\leq i < v.size() : v[i - 1] \\neq v[i]\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Todos los valores del vector son diferentes.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) No existen dos valores iguales en el vector.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Los valores del vector están ordenados en orden creciente.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 48
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación <br>\\({0 \\leq a.size}\\) [code]fun contarImpares(vector a) dev (int c)[/code] \\({c = \\#i : 0 \\leq i < a.size : a[i] \\% 2 = 1}\\)<br> y el siguiente algoritmo: [code]int contarImPares(std::vector const& a) {\n int c = 0;\n int k = a.size()-1;\n while (k >= 0) {\n  if (a[k] % 2 == 1) {\n   c = c + 1;\n  } \n  k = k - 1; \n }\n return c;\n}[/code] indica si el algoritmo es correcto con respecto a la especificación y en tal caso cuál es el invariante que permite demostrar la corrección del bucle.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Es correcto con invariante {\\(-1 \\leq k < a.size \\land c = \\#i : 0 \\leq i < k : a[i] \\% 2 = 1\\)}.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Es correcto con invariante {\\(-1 \\leq k \\leq a.size \\land c = \\#i : k \\leq i < a.size : a[i] \\% 2 = 1\\)}.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Es correcto con invariante {\\(-1 \\leq k \\leq a.size \\land c = \\#i : k < i < a.size : a[i] \\% 2 = 1\\)}.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 49
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes propiedades sobre los órdenes de complejidad no es correcta, siendo f y g funciones de coste cualesquiera:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(f + g) = \\Theta(\\max(f, g))\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(c \\cdot f) = c \\cdot \\Theta(f)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(\\log_a f) = \\Theta(\\log_b f)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 50
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál es una función de cota para este algoritmo: {x > 0} [code]int i = x;\nwhile (i >= 0)\n{\nif (i%2 == 1) {i = i + 1;}\ni = i - 1;\n} {i%2 = 1}[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) i + 1", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) x + i", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\max(0, i - 1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 51
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dados los algoritmos de búsqueda lineal y de búsqueda binaria, indica cuál de las siguientes afirmaciones es cierta (n indica el número de elementos del vector en que se realiza la búsqueda):");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Ambos algoritmos tienen el mismo orden de complejidad en el caso peor.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) El algoritmo de búsqueda lineal tiene coste \\(\\Theta(1)\\) y el de búsqueda binaria \\(\\Theta(\\log(n))\\).", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Ambos algoritmos se pueden aplicar sobre los mismos vectores de entrada.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 52
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "La siguiente especificación: <br>P : v.size ≥ 0 ∧ v = V [code]void f (vector <int> v)[/code] Q : ∀k : 0 ≤ k < v.size - 1 : v[k] ≤ v[k + 1] ∧ permutacion(v, V) <br>siendo el predicado permutacion(v, w) ≡ v.size() = w.size() ∧ ∀k : 0 ≤ k < v.size() : (#x : 0 ≤ x < v.size() : v[x] = v[k]) = (#x : 0 ≤ x < v.size() : w[x] = v[k]) <br>Se puede implementar con el siguiente algoritmo");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Algoritmo quicksort o de ordenación rápida.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Algoritmo de partición.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Algoritmo de búsqueda binaria.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 53
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica el coste de un algoritmo cuya recurrencia es: [code]T(n) = {\n 	c0 if n <= 2\n 	T(n/2) + c1 if n > 2\n       }[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(O(\\log n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) \\(O(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(O(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(O(n^2)\\)", FALSE);

-- Pregunta 54
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Si la precondición de un algoritmo es false, ¿qué afirmación es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Cualquier postcondición será válida.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Si se ejecuta el algoritmo dicha ejecución no terminará.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Si se ejecuta el algoritmo se producirá un error en tiempo de ejecución.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna postcondición será válida.", FALSE);

-- Pregunta 55
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes afirmaciones es incorrecta:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(O(\\log n) \\subset O(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(O(n^3) \\subset O(n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(2n \\in O(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(n \\log(n) \\in O(n^2)\\)", FALSE);

-- Pregunta 56
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int c = 1;\nfor (int i = 1; i < n; i++) c += 3;\nfor (int j = 1; j < n; j += 2) ++c;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 57
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "¿Qué significa el siguiente predicado para un vector no vacío de naturales? \\(\\forall i : 0 \\leq i < v.size() - 1 : v[i] \\neq v[i + 1]\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Todos los valores del vector son diferentes.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) No puede haber un mismo valor en una posición par y en una impar.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Los valores del vector están ordenados en orden decreciente.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 58
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación {0 ≤ a.size} [code]fun contarPares(vector a) dev (int c)[/code] {c = #i : 0 ≤ i < a.size : a[i] % 2 = 0} y el siguiente algoritmo: [code]int contarPares(std::vector const& a) {\nint c = 0;\nint k = a.size()-1;\nwhile (k >= 0) {\nif (a[k] % 2 == 0) {c = c + 1;}\nk = k - 1; }\nreturn c;\n}[/code] indica si el algoritmo es correcto con respecto a la especificación y en tal caso cuál es el invariante que permite demostrar la corrección del bucle.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Es correcto con invariante {−1 ≤ k < a.size ∧ c = #i : 0 ≤ i < k : a[i] % 2 = 0}.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Es correcto con invariante {−1 ≤ k ≤ a.size ∧ c = #i : k ≤ i < a.size : a[i] % 2 = 0}.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Es correcto con invariante {−1 ≤ k ≤ a.size ∧ c = #i : k < i < a.size : a[i] % 2 = 0}.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- --------------------------------------------------------------------------------------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Insertar el test 'Simulacro Examen FAL'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Simulacro Examen | FAL', 1, 10, TRUE, FALSE, 0.333);
SET @simulacro_fal_id := LAST_INSERT_ID();  -- Obtener el ID del nuevo test insertado

-- Asociar el nuevo test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@simulacro_fal_id, @ucm_id, @fal_id);

-- Insertar las preguntas del banco de preguntas "Examen Teórico FAL" en el "Simulacro Examen FAL"
INSERT INTO `preguntas` (`ID_test`, `pregunta`)
SELECT @simulacro_fal_id, `pregunta`
FROM `preguntas`
WHERE `ID_test` = @test_fal_id;

-- Copiar las opciones asociadas a las preguntas del banco de preguntas al simulacro
-- Primero, se necesita obtener los IDs de las preguntas originales y las preguntas en el simulacro
-- Suponemos que las preguntas se insertan en el mismo orden que en el banco original

-- Asumimos que el ID de la primera pregunta del banco original es @first_question_id del banco y @first_simulacro_question_id del simulacro
SET @first_question_id := (SELECT MIN(`ID_pregunta`) FROM `preguntas` WHERE `ID_test` = @test_fal_id);
SET @first_simulacro_question_id := (SELECT MIN(`ID_pregunta`) FROM `preguntas` WHERE `ID_test` = @simulacro_fal_id);

-- Insertar opciones para cada pregunta del simulacro
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`)
SELECT @simulacro_fal_id, `ID_pregunta` + @first_simulacro_question_id - @first_question_id, `ID_opcion`, `opcion`, `correcta`
FROM `opciones`
WHERE `ID_test` = @test_fal_id AND `ID_pregunta` >= @first_question_id;

/*  TEST MDL2 GRAFOS */

-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Obtener ID de MDL2
SET @mdl2_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MDL2' AND `ID_universidad` = @ucm_id);

-- Insertar el test 'Combinatoria MDL2'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Grafos | MDL2', 1, 31, TRUE, FALSE, 0.0);
SET @test_mdl2_id := LAST_INSERT_ID();  -- Obtener el ID del test recién insertado

-- Asociar el test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@test_mdl2_id, @ucm_id, @mdl2_id);

-- Pregunta 1
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Cualquier grafo de 120 vértices y 70 aristas tiene que ser inevitablemente:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Euleriano.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Conexo.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) No hamiltoniano.", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) Se necesita más información sobre las aristas para saberlo.", FALSE);

-- Pregunta 2
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Si un grafo no multigrafo, \\(G = (V, E)\\), es 5-regular y \\(|E| = 15\\), entonces con seguridad se verifica:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) G no es hamiltoniano.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) G es semi-euleriano.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) G es completo.", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(|V| = 5\\).", FALSE);
-- Pregunta 3
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea un grafo G = (V, E) tal que |E| = 17 y gr(v) ≥ 3 para todo v ∈ V. ¿Cuál es el mayor valor que podría tener |V|?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) 17", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) 14", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) 11", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) 6", FALSE);

-- Pregunta 4
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Marca la afirmación correcta:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Todo grafo G = (V, E) 2-regular tiene el mismo número de aristas que de vértices.", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) Ningún grafo G = (V, E) puede ser isomorfo a su grafo complementario G_c = (V, E_c).", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Sea G = (V, E) un grafo de n vértices y sea S la suma de los grados de los vértices de G, entonces la paridad de S depende de n.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Si un grafo G = (V, E) de n vértices es conexo y |E| = n + 1 entonces G contiene exactamente dos ciclos.", FALSE);

-- Pregunta 5
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Un grafo no dirigido tiene 11 nodos y 15 aristas. Si 10 de los nodos tienen grado 2, entonces:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) El otro es de grado 9 y el grafo es euleriano.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) El otro es de grado 9 y el grafo es semieuleriano.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) El otro es de grado 10 y el grafo es euleriano.", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea G = (V, E) un grafo no dirigido, donde V = {n ∈ N | 1 ≤ n ≤ 5} y E = {{n, m} | n ≠ m y n · m es par}. ¿Cuál de las siguientes afirmaciones sobre el grafo es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) G es semieuleriano y |E| = 14.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) G es hamiltoniano, |E| = 14 y gr(v) = 2 para todo v ∈ V impar.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) G es hamiltoniano y |E| = 7.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) G es euleriano, |E| = 7 y gr(v) = 4 para todo v ∈ V par.", TRUE);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dado el siguiente grafo, marca la afirmación correcta: [img]https://www.proxusacademy.com/wp-content/uploads/2024/05/Captura-de-pantalla-2024-05-01-180425.png[/img]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Es hamiltoniano y euleriano.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Es euleriano pero no hamiltoniano.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Es hamiltoniano y si se suprime el vértice 4 (y las aristas que inciden en él) sería semieuleriano.", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) No es ni hamiltoniano ni euleriano.", FALSE);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dados los siguientes grafos marca la afirmación correcta: [img]https://www.proxusacademy.com/wp-content/uploads/2024/05/Captura-de-pantalla-2024-05-01-170532.png[/img]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Sólo G1 y G2 son isomorfos.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Los tres grafos son isomorfos.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Sólo G2 y G3 son isomorfos.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Sólo G1 y G3 son isomorfos.", TRUE);


/*  TEST MDL2 COMBINATORIA */

-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Obtener ID de MDL2
SET @mdl2_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MDL2' AND `ID_universidad` = @ucm_id);

-- Insertar el test 'Combinatoria MDL2'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Combinatoria | MDL2', 1, 31, TRUE, FALSE, 0.0);
SET @test_mdl2_id := LAST_INSERT_ID();  -- Obtener el ID del test recién insertado

-- Asociar el test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@test_mdl2_id, @ucm_id, @mdl2_id);

-- Pregunta 1
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿Cuántos números diferentes se pueden obtener con secuencias de 6 bits con exactamente 2 ceros?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(2^5\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(2^4 \\cdot \\binom{6}{2}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{6}{2}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(2^6 - 2^5\\)", FALSE);

-- Pregunta 2
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Se quieren colocar 20 libros distintos en tres estanterías de distinta capacidad: en una hay espacio para 8 libros, en otra para 7 y en la tercera para 5. ¿De cuántas formas puede hacerse si no importa el orden en que quedan colocados en cada estantería?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(8! \\cdot 5! \\cdot 7!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\binom{20}{8} \\binom{20}{5} \\binom{20}{7}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\frac{20!}{8! \\cdot 5! \\cdot 7!}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) 20!", FALSE);

-- Pregunta 3
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿Cuántas palabras de longitud cuatro se pueden construir con las letras {A,B,C,D,E,F,G,H,I,J} que tengan exactamente dos Aes que además estén seguidas y que empiecen por una letra del conjunto {A,B,C,D,E}?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(9^2 + 2 \\times 9 \\times 4\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(4 \\times 2 \\times [9]^2\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{4}{2} \\times 9^2\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 4
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Se reparten n cuadernos iguales entre 5 estudiantes, m ejemplares entre los dos de más edad y el resto entre los otros tres. Si 0 < m < n, ¿de cuántas maneras posibles puede hacerse el reparto?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\((m)_2 (n - m)_3\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\binom{m}{2} (n-m)_3\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{2}{m} \\binom{3}{n-m}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\((m)_2! + (n - m)_3!\\)", FALSE);

-- Pregunta 5
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "El consejo de administración de una empresa está compuesto por 5 personas P1, P2, P3, P4, P5. Se somete a votación secreta la aprobación de un proyecto y nadie puede abstenerse pero sí puede votar en blanco. ¿Cuántos resultados distintos se pueden extraer de la urna una vez efectuada la votación?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(3^5\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(3^5\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{5}{3}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\binom{5}{3} \\cdot 5!\\)", FALSE);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿Cuántas reordenaciones de las letras de la palabra JAVIER tienen las tres vocales juntas?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(4!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(4! / 3!\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(3! / 3!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(3^2\\)", FALSE);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Una baraja de cartas española tiene 4 palos y 10 cartas por cada palo. ¿Cuántos grupos de 5 cartas pueden formarse con a lo sumo 2 espadas?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\binom{10}{2} \\cdot \\binom{30}{3}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\binom{10}{2} \\cdot \\binom{38}{3}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{10}{2} \\cdot \\binom{30}{3} + \\binom{10}{1} \\cdot \\binom{30}{4} + \\binom{10}{0} \\cdot \\binom{30}{5}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(10 \\cdot 9 \\cdot 30 \\cdot 29 \\cdot 28\\)", FALSE);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Tres amigos van al cine y quieren sentarse juntos en una fila de n butacas, que está vacía. ¿De cuántas formas distintas pueden hacerlo?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) 6(n - 2)", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) 3(n - 2)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{n}{3}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) n - 2", FALSE);

-- Pregunta 9
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Determina de cuántas formas se pueden colocar dos As y dos Bs en un tablero 4 x 4 de modo que en cada columna haya una y sólo una letra.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(4^4\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(4!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\binom{4}{2}4^4\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(6 \\cdot 4 \\cdot 3 \\cdot 2 \\cdot 2\\)", FALSE);

-- Pregunta 10
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Tenemos diez alumnos de un colegio. Tres tienen 8 años, dos 14 y cinco 10. ¿De cuántas formas se pueden colocar en una fila si queremos que estén agrupados por edad?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(6 \\cdot 3!2!5!\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(3!2!5!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(2 \\cdot 3!2!5!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\binom{3}{10} \\binom{2}{8} \\binom{5}{10}\\)", FALSE);

-- Pregunta 11
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿Cuántas palabras de 5 letras que contengan al menos una R pero ninguna A, pueden formarse con las letras de la palabra DISCRETA?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(8^5 - 7^5 / 5!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\sum_{i=1}^5 \\binom{5}{i} 6^{5-i}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(8^5 - 6!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(7^5 - 6!\\)", FALSE);

-- Pregunta 12
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿De cuántas formas se pueden alinear ocho personas A, B, C, D, E, F, G, H de modo que se cumplan simultáneamente los dos requisitos siguientes: A y H deben ocupar los extremos de la fila y B y C deben estar juntas?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(5!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(5! / 2\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(5! / 4\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(7! - 5! / 2\\)", FALSE);

-- Pregunta 13
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "El número de manos de 5 cartas de una baraja española de 40 cartas conteniendo al menos 3 espadas es:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\binom{10}{3} \\binom{30}{2}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\binom{10}{3} \\binom{30}{2} + \\binom{10}{4} \\binom{30}{1} + \\binom{10}{5}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(10 \\cdot 9 \\cdot 8 \\cdot 37 \\cdot 36\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\binom{10}{3} \\binom{27}{2}\\)", FALSE);

-- Pregunta 14
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿De cuántas maneras diferentes puede reordenarse la palabra CANSINAS?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\binom{8}{2,2,1,1,1,1}\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\binom{8}{2}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(8!\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\binom{8}{2}^4\\)", FALSE);

-- Pregunta 15
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "¿Cuántas palabras de 5 letras sobre el alfabeto A = {m, u, r, c, i, e, l, a, g, o} tienen alguna letra que aparece más de una vez?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(10^5\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(10^5 - (10)_5\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(10 \\cdot \\sum_{i=2}^5 \\binom{9}{i}5^{-i}\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\((10)_5\\)", FALSE);



/*  TEST MDL2 LÓGICA PROPOSICIONAL */

-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Obtener ID de MDL2
SET @mdl2_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MDL2' AND `ID_universidad` = @ucm_id);

-- Insertar el test 'Combinatoria MDL2'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Lógica Proposicional | MDL2', 1, 31, TRUE, FALSE, 0.0);
SET @test_mdl2_id := LAST_INSERT_ID();  -- Obtener el ID del test recién insertado

-- Asociar el test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@test_mdl2_id, @ucm_id, @mdl2_id);

-- Pregunta 1
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dada la fórmula proposicional \\(\\neg((\\neg p \\rightarrow r) \\rightarrow (p \\land r)), FND(\\phi)\\) puede ser:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\neg p \\land \\neg r\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\((\\neg p \\land r) \\lor (\\neg r \\land p)\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\neg p \\lor r\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(p \\lor \\neg r\\)", FALSE);

-- Pregunta 2
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "La fórmula proposicional \\(-(p \\rightarrow q) \\lor (\\neg p \\lor q)\\) es lógicamente equivalente a:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) T.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) ⊥.", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\neg (p \\rightarrow q)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(p \\rightarrow q\\)", FALSE);

-- Pregunta 3
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Indica en cuál de los siguientes casos la fórmula \\(\\phi \\rightarrow \\psi\\) es siempre contingencia:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\phi\\) y \\(\\psi\\) son contingencias.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\phi\\) es contradicción y \\(\\psi\\) es contingencia.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\neg \\phi\\) es contradicción y \\(\\psi\\) es contingencia.", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\neg \\phi\\) es contingencia y \\(\\psi\\) es tautología.", FALSE);

-- Pregunta 4
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea \\(\\Phi = \\{p \\rightarrow (r \\lor \\neg q), (p \\lor q)\\}\\). ¿Cuál de las siguientes afirmaciones es cierta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\Phi \\models r\\) porque no hay valoraciones contraejemplo.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\Phi \\not\\models r\\) y solo hay una valoración contraejemplo.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\Phi \\models \\neg r\\) porque no hay un tableau cerrado para \\(\\Phi \\cup \\{\\neg r\\}\\).", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Hay más de una valoración contraejemplo que prueba \\(\\Phi \\not\\models r\\).", TRUE);

-- Pregunta 5
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dada la fórmula proposicional \\(\\phi : ((q \\land r) \\rightarrow \\neg (p \\rightarrow q)) \\rightarrow \\neg (p \\rightarrow q), FND(\\phi)\\) puede ser:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\neg q \\land \\neg r \\lor (p \\land \\neg q)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\((p \\lor q) \\land (r \\lor p) \\land (\\neg p \\lor q) \\land (r \\lor \\neg p)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\((q \\land r) \\lor (\\neg p \\land \\neg q)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\((q \\land r) \\lor (p \\land \\neg q)\\)", TRUE);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Si \\(\\phi\\) y \\(\\psi\\) son contingencias, ¿cuál de las siguientes afirmaciones sobre la fórmula \\(\\phi \\lor \\psi\\) es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Puede ser contradicción.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Puede ser tautología.", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) Siempre es contingencia.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea \\(\\Phi = \\{(-p \\rightarrow -q(\\land r)), (q \\rightarrow r), p \\lor q \\lor r, r \\rightarrow p\\}\\). Entonces:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\Phi \\models r\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\Phi \\not\\models p\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\Phi \\models -p\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\Phi \\models -q\\)", FALSE);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dada la fórmula proposicional \\(\\phi = (p \\rightarrow (q \\rightarrow r)) \\rightarrow ((p \\rightarrow r) \\rightarrow q)\\), FNC(\\phi) puede ser:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\((p \\land \\neg r) \\lor q\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\((p \\lor q) \\land (\\neg r \\lor q)\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\((p \\lor \\neg r) \\land (\\neg r \\lor q)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\((p \\lor r) \\land (p \\lor \\neg q)\\)", FALSE);

-- Pregunta 9
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Considerando los símbolos de proposición siguientes:<br><br> p: Pedro ha estudiado<br> q: Quique ha estudiado<br> r: Ramón ha estudiado<br><br> la formalización correcta para el enunciado 'A lo sumo uno de los tres ha estudiado' sería:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(p \\land \\neg q \\land \\neg r \\lor \\neg p \\land q \\land \\neg r \\lor (\\neg p \\land \\neg q \\land r)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(p \\land \\neg q \\land \\neg r \\land (\\neg p \\land q \\land \\neg r \\land (\\neg p \\land \\neg q \\land r)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(p \\rightarrow (\\neg q \\land \\neg r) \\land (q \\rightarrow (\\neg p \\land \\neg r) \\land (r \\rightarrow (\\neg p \\land \\neg q))\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(p \\lor q \\lor r \\land (\\neg p \\lor \\neg q \\land (\\neg p \\lor \\neg r \\land (\\neg q \\lor \\neg r)\\)", FALSE);

-- Pregunta 10
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea T un tableau terminado construido a partir de la fórmula proposicional \\(\\neg \\phi\\). Si todas las ramas de T están abiertas se puede asegurar que:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\phi\\) no puede ser una tautología.", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\phi\\) no puede ser una contradicción.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\phi\\) no puede ser una contingencia.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

/*  TEST MDL2 LÓGICA DE PRIMER ORDEN */

-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Obtener ID de MDL2
SET @mdl2_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MDL2' AND `ID_universidad` = @ucm_id);

-- Insertar el test 'Combinatoria MDL2'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Lógica de Primer Orden | MDL2', 1, 31, TRUE, FALSE, 0.0);
SET @test_mdl2_id := LAST_INSERT_ID();  -- Obtener el ID del test recién insertado

-- Asociar el test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@test_mdl2_id, @ucm_id, @mdl2_id);

-- Pregunta 1
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Una forma normal prenexa de la fórmula \\(\\forall x(\\exists y(R(x, y) \\rightarrow \\forall z P(z)))\\) puede ser:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\exists x \\exists y (R(x, y) \\land \\neg P(y))\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\exists x \\forall y \\exists z (\\neg P(z) \\land R(x, y))\\)", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\exists x \\forall y \\forall z (P(z) \\land R(x, y))\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\exists x \\forall y \\exists z (\\neg R(x, y) \\lor P(z))\\)", FALSE);

-- Pregunta 2
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Todos los modelos de la fórmula \\(\\forall x \\exists y (R(x, y) \\land \\neg R(x, z))\\) tienen en su dominio:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Dos elementos exactamente.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Al menos dos elementos.", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) Uno o dos elementos.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Al menos un elemento.", FALSE);

-- Pregunta 3
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dado un conjunto de fórmulas \\(\\Phi = \\{\\phi_1, ..., \\phi_n\\}\\) y una fórmula \\(\\psi\\) tales que \\(\\Phi \\models \\neg \\psi\\), entonces podemos afirmar:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\models \\bigwedge_{i=1}^n \\phi_i \\rightarrow \\psi\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\text{Insat}(\\Phi \\cup \\{\\neg \\psi\\})\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\text{Sat}(\\bigwedge_{i=1}^n \\phi_i \\leftrightarrow \\psi)\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\text{Insat}(\\bigwedge_{i=1}^n \\phi_i \\land \\psi)\\)", TRUE);

-- Pregunta 4
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sean \\(\\phi_1 = \\exists x Q(x, y) \\rightarrow \\exists y Q(x, y)\\) y \\(\\phi_2 = \\forall x Q((x, y) \\rightarrow Q(y, x))\\) dos \\(\\Sigma\\)-fórmulas. Dada la \\(\\Sigma\\)-estructura \\(A = (A, \\emptyset, \\{Q^A\\}), donde A = \\{a, b\\}\\) y \\(Q^A = \\{(b, a)\\}\\), ¿cuál de las siguientes afirmaciones es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Si \\(\\sigma(x) = \\sigma(y) = a\\), entonces \\((A, \\sigma)\\) satisface \\(\\phi_1\\) y hace falsa a \\(\\phi_2\\).", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Si \\(\\sigma(x) = \\sigma(y) = b\\), entonces \\((A, \\sigma)\\) satisface \\(\\phi_2\\) y hace falsa a \\(\\phi_1\\).", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Si \\(\\sigma(x) = b\\) y \\(\\sigma(y) = a\\), entonces \\((A, \\sigma)\\) hace falsa a \\(\\phi_2\\) y satisface \\(\\phi_1\\).", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\((A, \\sigma)\\) satisface \\(\\phi_1\\) y \\(\\phi_2\\) si y solo si \\(\\sigma(x) = a\\) y \\(\\sigma(y) = b\\).", FALSE);

-- Pregunta 5
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sean \\(\\phi_1 = \\exists x R(x, y) \\rightarrow \\exists y R(x, y)\\) y \\(\\phi_2 = \\exists x (R(x, y) \\rightarrow R(y, x))\\) dos \\(\\Sigma\\)-fórmulas. Dada la \\(\\Sigma\\)-estructura \\(A = (A, \\emptyset, \\{R^A\\})\\), donde \\(A = \\{a, b\\}\\) y \\(R^A = \\{(a, b)\\}\\), ¿cuál de las siguientes afirmaciones es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Si \\(\\sigma(x) = a \\lor \\sigma(y) = b\\), entonces \\((A, \\sigma)\\) no satisface \\(\\phi_1\\) ni \\(\\phi_2\\).", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Si \\(\\sigma(x) = \\sigma(y) = a\\), entonces \\((A, \\sigma)\\) satisface \\(\\phi_1\\) y hace falsa a \\(\\phi_2\\).", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Si \\(\\sigma(x) = \\sigma(y) = b\\), entonces \\((A, \\sigma)\\) satisface \\(\\phi_2\\) y hace falsa a \\(\\phi_1\\).", TRUE),
(@test_mdl2_id, @pregunta_id, 4, "d) Las afirmaciones anteriores son falsas.", FALSE);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea \\(\\Phi = \\{\\phi_1,...,\\phi_n\\}\\) un conjunto de fórmulas proposicionales. Indica la respuesta correcta.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Si \\(\\Phi\\) es satisfactible, entonces para cualquier i, 1 ≤ i ≤ n, \\(\\Phi \\setminus \\{\\phi_i\\}\\) es satisfactible", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) Si \\(\\Phi \\models \\phi\\), entonces para cualquier i, 1 ≤ i ≤ n, \\(\\Phi \\setminus \\{\\phi_i\\} \\not\\models \\phi\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Si \\(\\Phi\\) es satisfactible y \\(\\psi\\) también, entonces \\(\\Phi \\cup \\{\\psi\\}\\) es satisfactible", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Si \\(\\Phi\\) es insatisfactible y \\(\\psi\\) es una tautología, entonces \\(\\Phi \\cup \\{\\psi\\}\\) es satisfactible", FALSE);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sean \\(\\phi = \\forall P(x) \\leftrightarrow \\forall Q(x) = y\\) y \\(\\psi = \\exists P(x) = z \\leftrightarrow \\exists Q(x)\\) ¿cuál de las siguientes afirmaciones es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) \\(\\phi \\equiv \\psi\\) o \\(\\psi \\equiv \\phi\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) \\(\\phi \\Rightarrow \\psi\\) o \\(\\psi \\Rightarrow \\phi\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) \\(\\phi \\wedge \\psi\\)", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) \\(\\phi \\not\\equiv \\psi\\)", TRUE);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Sea \\(\\phi = \\exists x((P(x) \\land Q(x)) \\land \\forall y(P(y) \\rightarrow P(f(y))) \\land \\neg Q(f(y)))\\) una fórmula de primer orden, entonces cualquier modelo de la fórmula tiene en su dominio:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Al menos dos elementos.", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) Al menos tres elementos.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) A lo más dos elementos.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Exactamente dos elementos", FALSE);

-- Pregunta 9
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dadas las dos siguientes afirmaciones, -\\(\\exists P(x)\\) \\(\\lor \\forall y(\\exists P(z) \\rightarrow P(y))\\) y \\(\\exists P(x) \\rightarrow \\forall Q(x)\\) \\(\\lor \\forall z(P(x) \\rightarrow Q(x))\\), ¿cuál es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Ambas son ciertas.", TRUE),
(@test_mdl2_id, @pregunta_id, 2, "b) Ambas son falsas.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Solamente es cierta la segunda.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Solamente es cierta la primera.", FALSE);

-- Pregunta 10
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Dadas las dos siguientes afirmaciones, \\(\\forall x (P(x) \\rightarrow Q(x)) \\sim \\neg \\forall x P(x) \\lor \\forall x Q(x)\\) y \\(\\exists x (P(x) \\rightarrow Q(x)) \\sim \\neg \\exists x P(x) \\lor \\exists x Q(x)\\), ¿cuál es correcta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Ambas son ciertas.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Ambas son falsas.", TRUE),
(@test_mdl2_id, @pregunta_id, 3, "c) Solamente es cierta la primera.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Solamente es cierta la segunda.", FALSE);

-- Pregunta 11
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_mdl2_id, "Cualquier modelo de la fórmula \\(\\forall x \\exists y (R(x, y) \\land \\neg R(x, z))\\) tiene en su universo de discurso:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_mdl2_id, @pregunta_id, 1, "a) Exactamente 1 elemento.", FALSE),
(@test_mdl2_id, @pregunta_id, 2, "b) Exactamente 2 elementos.", FALSE),
(@test_mdl2_id, @pregunta_id, 3, "c) Como mucho 2 elementos.", FALSE),
(@test_mdl2_id, @pregunta_id, 4, "d) Al menos 2 elementos.", TRUE);
