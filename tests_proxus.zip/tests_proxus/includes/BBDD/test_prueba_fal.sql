CREATE DATABASE IF NOT EXISTS flexam;
USE flexam;

CREATE TABLE `usuarios` (
  `ID_usuario` INT AUTO_INCREMENT PRIMARY KEY,
  `user` VARCHAR(255) NOT NULL,
  `psw` VARCHAR(255) NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  `apellidos` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `ID_universidad` INT,
  `ID_grado` INT,
  `rol` VARCHAR(255) NOT NULL
);

CREATE TABLE `universidades` (
  `ID_universidad` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(255) NOT NULL,
  `abreviatura` VARCHAR(5) NOT NULL,
  `ciudad` VARCHAR(255) NOT NULL
);

CREATE TABLE `grados` (
  `ID_grado` INT AUTO_INCREMENT PRIMARY KEY,
  `ID_universidad` INT NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  FOREIGN KEY (`ID_universidad`) REFERENCES `universidades`(`ID_universidad`)
);

CREATE TABLE `asignaturas` (
  `ID_asignatura` INT AUTO_INCREMENT PRIMARY KEY,
  `ID_universidad` INT NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  `abreviatura` VARCHAR(5) NOT NULL,
  FOREIGN KEY (`ID_universidad`) REFERENCES `universidades`(`ID_universidad`)
);

CREATE TABLE `grado_asignatura` (
  `ID_grado` INT NOT NULL,
  `ID_asignatura` INT NOT NULL,
  PRIMARY KEY (`ID_grado`, `ID_asignatura`),
  FOREIGN KEY (`ID_grado`) REFERENCES `grados`(`ID_grado`),
  FOREIGN KEY (`ID_asignatura`) REFERENCES `asignaturas`(`ID_asignatura`)
);

CREATE TABLE `tests` (
  `ID_test` INT AUTO_INCREMENT PRIMARY KEY,
  `titulo` VARCHAR(255) NOT NULL,
  `ID_usuario` INT NOT NULL,
  `num_preguntas` INT NOT NULL,
  `es_publico` BOOLEAN NOT NULL,
  `es_anonimo` BOOLEAN NOT NULL,
  `resta` DECIMAL(5,3),
  FOREIGN KEY (`ID_usuario`) REFERENCES `usuarios`(`ID_usuario`)
);

CREATE TABLE `test_asignatura` (
  `ID_test` INT NOT NULL,
  `ID_universidad` INT NOT NULL,
  `ID_asignatura` INT NOT NULL,
  PRIMARY KEY (`ID_test`, `ID_universidad`, `ID_asignatura`),
  FOREIGN KEY (`ID_test`) REFERENCES `tests`(`ID_test`),
  FOREIGN KEY (`ID_universidad`) REFERENCES `universidades`(`ID_universidad`),
  FOREIGN KEY (`ID_asignatura`) REFERENCES `asignaturas`(`ID_asignatura`)
);

CREATE TABLE `preguntas` (
  `ID_pregunta` INT AUTO_INCREMENT PRIMARY KEY,
  `ID_test` INT NOT NULL,
  `pregunta` TEXT NOT NULL,
  FOREIGN KEY (`ID_test`) REFERENCES `tests`(`ID_test`)
);

CREATE TABLE `opciones` (
  `ID_test` INT NOT NULL,
  `ID_pregunta` INT NOT NULL,
  `ID_opcion` INT NOT NULL,
  `opcion` TEXT NOT NULL,
  `correcta` BOOLEAN NOT NULL,
  PRIMARY KEY (`ID_test`, `ID_pregunta`, `ID_opcion`),
  FOREIGN KEY (`ID_test`, `ID_pregunta`) REFERENCES `preguntas`(`ID_test`, `ID_pregunta`)
);

CREATE TABLE `respuesta_usuario` (
  `ID_test` INT NOT NULL,
  `ID_usuario` INT NOT NULL,
  `ID_intento` INT AUTO_INCREMENT PRIMARY KEY,
  `nota` DECIMAL(5,2) NOT NULL,
  `aciertos` INT NOT NULL,
  `fecha` TIMESTAMP NOT NULL,
  FOREIGN KEY (`ID_test`) REFERENCES `tests`(`ID_test`),
  FOREIGN KEY (`ID_usuario`) REFERENCES `usuarios`(`ID_usuario`)
);

CREATE TABLE `codigos_registro` (
  `codigo` CHAR(8) PRIMARY KEY,
  `usado` BOOLEAN NOT NULL DEFAULT FALSE
);

INSERT INTO `codigos_registro` (`codigo`, `usado`) VALUES
('28L09TF3', FALSE),
('3IETJPSW', FALSE),
('3W4ZYZ4J', FALSE),
('7QMT2E79', FALSE),
('7SD7PUB7', FALSE),
('860DFRO8', FALSE),
('8OQ0FC59', FALSE),
('8U4AZKPM', FALSE),
('CHNAF4ET', FALSE),
('E9EFPRDI', FALSE),
('EAK7FXLC', FALSE),
('FA5KFIVK', FALSE),
('GG838E38', FALSE),
('I6IT2PW3', FALSE),
('ITZS9QB9', FALSE),
('KJX95BDH', FALSE),
('MJQEHL5K', FALSE),
('Q025HNT8', FALSE),
('S40OT9AI', FALSE),
('Z83CZPBL', FALSE);

ALTER TABLE `usuarios` ADD FOREIGN KEY (`ID_universidad`) REFERENCES `universidades` (`ID_universidad`);
ALTER TABLE `usuarios` ADD FOREIGN KEY (`ID_grado`) REFERENCES `grados` (`ID_grado`);

  /* Insercion de datos */
-- Insertando universidades
INSERT INTO `universidades` (`nombre`, `abreviatura`, `ciudad`) VALUES
('Universidad Complutense de Madrid', 'UCM', 'Madrid'),
('Universidad Politécnica de Madrid', 'UPM', 'Madrid'),
('Universidad de Barcelona', 'UB', 'Barcelona'),
('IE University', 'IE', 'Madrid');

-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Grados en la UCM
INSERT INTO `grados` (`ID_universidad`, `nombre`) VALUES
(@ucm_id, 'Doble Grado en Ingeniería Informática y Administración de Empresas'),
(@ucm_id, 'Ingeniería de Software'),
(@ucm_id, 'Psicología');

INSERT INTO usuarios (user, psw, nombre, apellidos, email, ID_universidad, ID_grado, rol) VALUES
('flex', '$2y$10$ju5ai6teON3lyG45i0pk4e1ijKD0TiOazMnKN2RIFuQnHD8Z/zhwq', 'Flex', 'Exam', 'flex@exam.com', 1, 1, 'estudiante'),
('adminUser', '$2y$10$4GYa1wDT3PeeL7ywGXjfSuoU4lAzBnMP/fGUHJkcNOTnHMtba8A5u', 'Admin', 'User', 'admin@user.com', NULL, NULL, 'admin');

-- Asignaturas comunes y específicas de los grados en UCM
INSERT INTO `asignaturas` (`ID_universidad`, `nombre`, `abreviatura`) VALUES
(@ucm_id, 'Fundamentos de la Programación 1', 'FP1'),
(@ucm_id, 'Fundamentos de Computadores 1', 'FC1'),
(@ucm_id, 'Aplicaciones Web', 'AW'),
(@ucm_id, 'Auditoría Informática 1', 'AI1'),
(@ucm_id, 'Márketing', 'MKT'),
(@ucm_id, 'Fundamentos de Algoritmia', 'FAL');

-- Obtener ID de los grados de UCM
SET @dobleg_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'Doble Grado en Ingeniería Informática y Administración de Empresas' AND `ID_universidad` = @ucm_id);
SET @softeng_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'Ingeniería de Software' AND `ID_universidad` = @ucm_id);

-- Obtener ID de las asignaturas
SET @fp1_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'FP1' AND `ID_universidad` = @ucm_id);
SET @fc1_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'FC1' AND `ID_universidad` = @ucm_id);
SET @aw_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'AW' AND `ID_universidad` = @ucm_id);
SET @ai1_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'AI1' AND `ID_universidad` = @ucm_id);
SET @mkt_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'MKT' AND `ID_universidad` = @ucm_id);
SET @fal_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'FAL' AND `ID_universidad` = @ucm_id);

-- Asociar grados y asignaturas en UCM
INSERT INTO `grado_asignatura` (`ID_grado`, `ID_asignatura`) VALUES
(@dobleg_id, @fp1_id),
(@dobleg_id, @fc1_id),
(@dobleg_id, @aw_id),
(@dobleg_id, @ai1_id),
(@dobleg_id, @mkt_id),
(@dobleg_id, @fal_id),
(@softeng_id, @fp1_id),
(@softeng_id, @fc1_id),
(@softeng_id, @aw_id);

-- Grados para la Universidad Politécnica de Madrid (UPM)
INSERT INTO `grados` (`ID_universidad`, `nombre`) VALUES
(2, 'Grado en Arquitectura'),
(2, 'Grado en Ingeniería Aeroespacial');

-- Grados para la Universidad de Barcelona (UB)
INSERT INTO `grados` (`ID_universidad`, `nombre`) VALUES
(3, 'Grado en Derecho'),
(3, 'Grado en Medicina');

-- Asignaturas para la Universidad Politécnica de Madrid (UPM)
INSERT INTO `asignaturas` (`ID_universidad`, `nombre`, `abreviatura`) VALUES
(2, 'Diseño Arquitectónico', 'DA'),
(2, 'Cálculo de Estructuras', 'CE'),
(2, 'Mecánica de Fluidos', 'MF'),
(2, 'Diseño de Circuitos', 'DC'),
(2, 'Aerodinámica', 'AD');

-- Asignaturas para la Universidad de Barcelona (UB)
INSERT INTO `asignaturas` (`ID_universidad`, `nombre`, `abreviatura`) VALUES
(3, 'Derecho Romano', 'DR'),
(3, 'Derecho Civil', 'DCIV'),
(3, 'Anatomía Humana', 'AH'),
(3, 'Bioquímica', 'BQ'),
(3, 'Fisiología', 'FIS');

-- Asignaturas para IE University
INSERT INTO `grados` (`ID_universidad`, `nombre`) VALUES
(4, 'Business & Management');

-- Obtener IDs de grados de la UPM
SET @arq_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'Grado en Arquitectura');
SET @aero_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'Grado en Ingeniería Aeroespacial');

-- Asignaturas compartidas entre grados en la UPM
-- Suponiendo que todas las asignaturas son compartidas
INSERT INTO `grado_asignatura` (`ID_grado`, `ID_asignatura`) SELECT @arq_id, `ID_asignatura` FROM `asignaturas` WHERE `ID_universidad` = 2;
INSERT INTO `grado_asignatura` (`ID_grado`, `ID_asignatura`) SELECT @aero_id, `ID_asignatura` FROM `asignaturas` WHERE `ID_universidad` = 2;

-- Obtener IDs de grados de la UB
SET @derecho_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'Grado en Derecho');
SET @medicina_id := (SELECT `ID_grado` FROM `grados` WHERE `nombre` = 'Grado en Medicina');

-- Asignaturas compartidas entre grados en la UB
-- Suponiendo que las asignaturas 'Derecho Romano' y 'Derecho Civil' son para 'Grado en Derecho'
-- y 'Anatomía Humana', 'Bioquímica' y 'Fisiología' son para 'Grado en Medicina'
INSERT INTO `grado_asignatura` (`ID_grado`, `ID_asignatura`) SELECT @derecho_id, `ID_asignatura` FROM `asignaturas` WHERE `ID_universidad` = 3 AND `abreviatura` IN ('DR', 'DCIV');
INSERT INTO `grado_asignatura` (`ID_grado`, `ID_asignatura`) SELECT @medicina_id, `ID_asignatura` FROM `asignaturas` WHERE `ID_universidad` = 3 AND `abreviatura` IN ('AH', 'BQ', 'FIS');

/* CREACION TESTS */
-- Insertar el test de Marketing
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`) VALUES
('Preparación examen final de Marketing', 1, 7, TRUE, FALSE);

-- Obtener el ID del test de marketing para usarlo en las inserciones subsiguientes
SET @test_id := LAST_INSERT_ID();

-- Pregunta 1
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué es el marketing mix?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Es una técnica para determinar el precio de los productos de una empresa.", 0),
(@test_id, @pregunta_id, 2, "b) Es una herramienta utilizada para definir la estrategia de promoción de una empresa.", 0),
(@test_id, @pregunta_id, 3, "c) Es un conjunto de variables controlables que la empresa utiliza para alcanzar los objetivos de marketing en el mercado objetivo.", 1),
(@test_id, @pregunta_id, 4, "d) Es un concepto relacionado con la distribución de los productos en el mercado.", 0);

-- Pregunta 2
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Cuál de las siguientes NO es una de las 4 P's del marketing mix?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Precio", 0),
(@test_id, @pregunta_id, 2, "b) Producto", 0),
(@test_id, @pregunta_id, 3, "c) Publicidad", 1),
(@test_id, @pregunta_id, 4, "d) Plaza", 0);

-- Pregunta 3
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué es el mercado meta?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Es el mercado en el que la empresa decide ingresar con su producto o servicio.", 0),
(@test_id, @pregunta_id, 2, "b) Es el segmento de mercado al que la empresa dirige sus esfuerzos de marketing.", 1),
(@test_id, @pregunta_id, 3, "c) Es el conjunto de todas las empresas que ofrecen productos similares en el mercado.", 0),
(@test_id, @pregunta_id, 4, "d) Es el grupo de consumidores que tienen una necesidad insatisfecha.", 0);

-- Pregunta 4
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Cuál de las siguientes NO es una estrategia de segmentación de mercado?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Segmentación geográfica", 0),
(@test_id, @pregunta_id, 2, "b) Segmentación demográfica", 0),
(@test_id, @pregunta_id, 3, "c) Segmentación psicológica", 0),
(@test_id, @pregunta_id, 4, "d) Segmentación monolítica", 1);

-- Pregunta 5
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué es el posicionamiento en marketing?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Es el proceso de crear una imagen única y distintiva en la mente de los consumidores para un producto o marca.", 1),
(@test_id, @pregunta_id, 2, "b) Es la acción de fijar el precio de un producto o servicio de acuerdo con la percepción del consumidor.", 0),
(@test_id, @pregunta_id, 3, "c) Es la estrategia que utiliza la empresa para distribuir sus productos en el mercado.", 0),
(@test_id, @pregunta_id, 4, "d) Es el conjunto de actividades que realiza la empresa para promover su producto o servicio.", 0);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Cuál de las siguientes NO es una variable del marketing mix?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Precio", 0),
(@test_id, @pregunta_id, 2, "b) Producto", 0),
(@test_id, @pregunta_id, 3, "c) Promoción", 0),
(@test_id, @pregunta_id, 4, "d) Población", 1);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué es el análisis FODA?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Es una herramienta de diagnóstico que permite identificar las Fortalezas, Oportunidades, Debilidades y Amenazas de una empresa.", 1),
(@test_id, @pregunta_id, 2, "b) Es una técnica para analizar la rentabilidad de un producto o servicio en el mercado.", 0),
(@test_id, @pregunta_id, 3, "c) Es un método para determinar el precio óptimo de un producto o servicio.", 0),
(@test_id, @pregunta_id, 4, "d) Es una estrategia de marketing para aumentar la participación en el mercado.", 0);



-- Insertar el test de Auditoría Informática
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`) VALUES
('Módulo 1', 1, 10, TRUE, FALSE);

-- Obtener el ID del test de Auditoría Informática
SET @test_id := LAST_INSERT_ID();

-- Pregunta 1
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué expresión se ajusta mejor al concepto de auditoría?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`,  `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Proceso sistemático e independiente para obtener evidencias y evaluarlas de una manera objetiva con el fin de determinar la extensión en que se cumplen los criterios del referente utilizado.", 0),
(@test_id, @pregunta_id, 2, "b) Proceso sistemático para obtener evidencias y evaluarlas de una manera objetiva con el fin de determinar la extensión en que se cumplen los criterios del referente utilizado.", 0),
(@test_id, @pregunta_id, 3,  "c) Proceso sistemático, independiente y documentado para obtener evidencias y evaluarlas de una manera objetiva con el fin de determinar la extensión en que se cumplen los criterios del referente utilizado.", 1),
(@test_id, @pregunta_id, 4, "d) Proceso sistemático, independiente y no documentado para obtener evidencias y evaluarlas de una manera objetiva con el fin de determinar la extensión en que se cumplen los criterios del referente utilizado.", 0);

-- Pregunta 2
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué expresión se ajusta mejor al concepto de evidencia?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Registros, declaraciones de hecho o cualquier otra información que son pertinentes según la ISO/IEC 19011.", 0),
(@test_id, @pregunta_id, 2, "b) Registros, declaraciones de hecho o cualquier otra información que son pertinentes según el referente de auditoría y que son verificables.", 1),
(@test_id, @pregunta_id, 3, "c) Registros, declaraciones de hecho o cualquier otra información que no son pertinentes según el referente de auditoría y que son verificables.", 0),
(@test_id, @pregunta_id, 4, "d) Registros, declaraciones de hecho o cualquier otra información que son pertinentes según el referente de auditoría, que son verificables y que no sean repetibles.", 0);

-- Pregunta 3
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "El estándar ISO/IEC 27001 ha sido publicado por:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) ENAC", 0),
(@test_id, @pregunta_id, 2, "b) BSI", 0),
(@test_id, @pregunta_id, 3, "c) AENOR", 0),
(@test_id, @pregunta_id, 4, "d) ISO", 1);

-- Pregunta 4
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "Las propiedades que debe reunir una evidencia son:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Verificable, auténtica, repetible y analítica.", 0),
(@test_id, @pregunta_id, 2, "b) Verificable, auténtica, cíclica y neutra.", 0),
(@test_id, @pregunta_id, 3, "c) Medible, auténtica, repetible y neutra.", 0),
(@test_id, @pregunta_id, 4, "d) Verificable, auténtica, repetible y neutra.", 1);

-- Pregunta 5
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "Qué opción reúne el mayor número de procedimientos para obtener evidencias son:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Tratamiento documental, inspección física, entrevista y observación.", 0),
(@test_id, @pregunta_id, 2, "b) Inspección documental, inspección lógica, entrevista y observación.", 0),
(@test_id, @pregunta_id, 3, "c) Inspección documental, inspección física, álgebra, entrevista y observación.", 0),
(@test_id, @pregunta_id, 4, "d) Inspección documental, inspección física, entrevista y observación.", 1);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué opción se ajusta mejor a la definición de auditoría externa de segunda parte?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Los auditores internos de una organización auditan a sus proveedores o a un proveedor potencial para determinar la viabilidad de su incorporación a la empresa en calidad de tal.", 1),
(@test_id, @pregunta_id, 2, "b) Una organización independiente, acreditada, audita a una organización, para determinar si cumple con una determinada norma.", 0),
(@test_id, @pregunta_id, 3, "c) Cuando una organización realiza una evaluación o auditoría interna por personal con experiencia e independiente con las funciones evaluadas.", 0),
(@test_id, @pregunta_id, 4, "d) Los auditores internos de una organización independiente y acreditada auditan a sus proveedores o a un proveedor potencial para determinar la viabilidad de su incorporación a la empresa en calidad de tal.", 0);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "El estándar UNE-ISO/IEC 27001 ha sido publicado por:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) ENAC", 0),
(@test_id, @pregunta_id, 2, "b) BSI", 0),
(@test_id, @pregunta_id, 3, "c) AENOR", 1),
(@test_id, @pregunta_id, 4, "d) ISO", 0);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "En España las entidades de certificación son acreditadas por:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) ENAC.", 1),
(@test_id, @pregunta_id, 2, "b) AENOR.", 0),
(@test_id, @pregunta_id, 3, "c) UKAS.", 0),
(@test_id, @pregunta_id, 4, "d) BSI.", 0);

-- Pregunta 9
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "Según el código profesional de ética de ISACA, el auditor debe:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Informar sobre los resultados del trabajo realizado sólo a su organización de auditoría, revelando todos los hechos significativos sobre los cuales tengan conocimiento.", 0),
(@test_id, @pregunta_id, 2, "b) Informar sobre los resultados del trabajo realizado a las partes apropiadas, revelando todos los hechos significativos y también los pertinentes sobre los cuales tengan conocimiento.", 1),
(@test_id, @pregunta_id, 3, "c) Informar sobre los resultados del trabajo realizado a las partes apropiadas, revelando parte los hechos significativos sobre los cuales tengan conocimiento.", 0),
(@test_id, @pregunta_id, 4, "d) Informar sobre los resultados del trabajo realizado a las partes apropiadas, revelando todos los hechos significativos sobre los cuales tengan conocimiento.", 0);

-- Pregunta 10
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_id, "¿Qué opción es la mejor respecto a las propiedades éticas que debe reunir el auditor?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_id, @pregunta_id, 1, "a) Independencia, integridad, imparcialidad, secreto profesional y competencia profesional.", 0),
(@test_id, @pregunta_id, 2, "b) Independencia, integridad, objetividad, imparcialidad, secreto profesional y competencia profesional.", 1),
(@test_id, @pregunta_id, 3, "c) Independencia, integridad, objetividad, parcialidad, secreto profesional y competencia profesional.", 0),
(@test_id, @pregunta_id, 4, "d) Independencia, integridad, objetividad, imparcialidad, secreto profesional y competencia estructural.", 0);


INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES 
('1', '1', '5'), ('2', '1', '4'); 
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------

-- --------------------------------------------------------------------------------------------------------------------------------------------------------------


-- ID de la UCM
SET @ucm_id := (SELECT `ID_universidad` FROM `universidades` WHERE `abreviatura` = 'UCM');

-- Obtener ID de FAL
SET @fal_id := (SELECT `ID_asignatura` FROM `asignaturas` WHERE `abreviatura` = 'FAL' AND `ID_universidad` = @ucm_id);

-- Insertar el test 'Prueba 1 FAL'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Banco de Preguntas | Examen Teórico FAL', 1, 31, TRUE, FALSE, 0.333);
SET @test_fal_id := LAST_INSERT_ID();  -- Obtener el ID del test recién insertado

-- Asociar el test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@test_fal_id, @ucm_id, @fal_id);

-- Pregunta 1: Complejidad de un algoritmo que verifica un vector decreciente
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo que comprueba si un vector de \\( n \\) elementos es estrictamente decreciente tiene complejidad en el caso mejor:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(1)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 2: Coste peor caso del algoritmo de ordenación por inserción
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El coste en el caso peor del algoritmo de ordenación por inserción sobre un vector de \\( n \\) elementos está en:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(2^n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Theta(n^2)\\)", TRUE);

-- Pregunta 3: Complejidad de inserción en vector no ordenado
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo para insertar un elemento en un vector no necesariamente ordenado sin elementos repetidos (de forma que siga sin tener elementos repetidos) tiene complejidad en el caso peor (la más ajustada):");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Theta(n \\log n)\\)", FALSE);

-- Pregunta 4: Búsqueda del mínimo en vector ordenado
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo que busca el mínimo en un vector ordenado de n elementos tiene complejidad en el caso peor:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 5: Complejidad de un algoritmo anidado
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int a = 0;\nfor (int i = 0; i < n+20; ++i)\n   for (int j = m+30; j >= 0; --j)\n    --a;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n^m)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(\\max(n, m))\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 6
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int a = 0;\nfor (int i = 1; i < n; i *= 3)\n    --a;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(n \\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(n^2)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 7
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> \\(\\{ 0 \\leq n \\leq \\text{long}(v) \\}\\)\n\n[code]fun xxx (int v[], int n, int x) dev int r[/code]\n\n\\(\\{ r = \\# u : 0 \\leq u < n : v[u] < x \\}\\) <br>y teniendo en cuenta que estamos considerando los n primeros elementos del vector, indica qué afirmación es correcta con respecto a ella.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) La postcondición está mal definida cuando n=0.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) El valor de r es la posición en el vector del último elemento menor que x.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El valor de r es la posición en el vector del primer elemento menor que x.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 8
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> \\(\\{ 0 < n \\leq \\text{longitud}(v) \\}\\)\n\n[code]fun xxx (int v[], int n) dev int r[/code]\n\n\\(\\{ r = \\max u : 0 \\leq u < n \\land u \\)(\\ \\mod 2 = 0 : v[u] \\}\\) <br>y teniendo en cuenta que estamos considerando los n primeros elementos del vector, indica qué afirmación es correcta con respecto a ella.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El valor de r es la posición más a la derecha que contiene un elemento par.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) El valor de r es el máximo de los elementos pares del vector.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El valor de r es el máximo de los elementos del vector que se encuentran en posiciones pares.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 9
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la siguiente especificación y valores de los parámetros de entrada, indica cuál es el valor del resultado: <br> \\(\\{ 0 \\leq n \\leq \\text{longitud}(v) \\}\\)\n\n[code]fun xxx (int v[], int n) dev int r[/code]\n\n\\(\\{ r = \\# u : 0 \\leq u < n\\)(\\ : \\text{suma}(v,0,u) < \\text{suma}(v,u+1,n) \\}\\) <br>siendo<br>\\(\\text{suma}(v,c,f) = \\sum z : c \\leq z < f : v[z]\\) <br>Datos de entrada: n=5, v=[1,-1,1,-1,1]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) r = 3.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) r = 0.", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) r = 2.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 10
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica si la siguiente afirmación es verdadera o falsa: <br> \\(2n + n^{10} \\in \\Omega(n^{10})\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Verdadero", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Falso", FALSE);

-- Pregunta 11
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes afirmaciones es incorrecta:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(O(\\log n) \\subset O(2^n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(O(\\sqrt{n}) \\subset O(n^3)\\)", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Omega(1) \\subset \\Omega(n^2)\\)", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) \\(\\Omega(n) \\subset \\Omega(2n)\\)", FALSE);

-- Pregunta 12
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El siguiente predicado es más débil que cualquier otro predicado: <br> \\(x > 0 \\lor x < 0\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Verdadero", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Falso", TRUE);

-- Pregunta 13
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El siguiente predicado es más débil que cualquier otro predicado: <br> \\(\\text{false} \\rightarrow \\text{true}\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Falso", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Verdadero", TRUE);

-- Pregunta 14
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dado un vector v con N elementos, ¿qué representa la siguiente expresión? <br> \\(\\max p, q : 0 \\leq p \\leq q \\leq N \\) \\( \\land P(v, p, q) : q - p\\) <br>siendo <br>\\(P(v, p, q) = \\forall l : p \\leq l < q \\) \\(: v[l] \\geq 0 \\land v[l] \\mod 2 = 0\\)");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El número de posiciones del vector cuyos elementos cumplen la propiedad de ser pares.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) La resta de las dos mayores posiciones del vector cuyos elementos cumplen la propiedad de ser pares.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El máximo número de posiciones consecutivas cuyos elementos cumplen la propiedad de ser pares.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", FALSE);

-- Pregunta 15
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál es la precondición más débil: <br> {\\({???}\\)} <br>  \\(x = y;\\) <br>\t\\(y = x;\\) <br>\t{\\({x == 3 \\land y == 4}\\)}");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) y \\(\\neq\\) x", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) y == 3 \\(\\land\\) x == 4", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) true", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);

-- Pregunta 16
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "¿Cuál de estas afirmaciones es correcta? (x e y variables de tipo entero).");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) {x > 0 \\(\\land\\) y < 0} nada {x + y > 0}", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) {x + y > 0} nada {x > 0}", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) {x > 0 \\(\\land\\) y > 0} nada {x / y > 0}", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores", TRUE);


-- Pregunta 17
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál es la afirmación correcta acerca de este algoritmo de búsqueda binaria en el que la precondición es \\(0 \\leq c \\leq f + 1 \\leq \\text{longitud}(v)\\): [code]int f(int v[], int x, int c, int f) {\n    int resultado;\n    if (c > f)\n        {resultado = c-1;}\n    else\n    {\n        int m = (c+f)/2;\n        if (v[m] > x)\n          {resultado = f(v, x, c, m);}\n        else\n          {resultado = f(v, x, m, f);}\n    }\n    return resultado;\n}[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Sólo termina si c < f.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Nunca termina.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Siempre termina.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", TRUE);

-- Pregunta 18
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "La generalización es una técnica que se utiliza para:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Todas son correctas", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Diseñar algoritmos recursivos.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Mejorar la eficiencia de los algoritmos recursivos.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Disponer de funciones más generales que la que se deseaba.", FALSE);

-- Pregunta 19
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "En los algoritmos recursivos en los que se reduce el tamaño del problema por sustracción: <br> \\(T(n) = c_0 \\text{ si } 0 \\leq n \\leq n_0\\) <br> \\(T(n) = aT(n - b) + cn^k \\text{ si } n > n_0\\):");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Para que sea polinómico es necesario que b>a.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Si a = 1 el coste es logarítmico.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Si a>1, es siempre exponencial por muy grande que sea b.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 20
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dado el siguiente algoritmo que calcula la raíz cuadrada entera de un número dado x: <br> {\\(x \\geq 0\\)}[code]r=0;\nwhile ((r+1)*(r+1)<=x){\n  r=r+1; \n}\n[/code]{\\(r >= 0 \\land r*r \\leq x < (r + 1)*(r + 1)\\)} <br> Indica cuáles de las siguientes funciones de cota no demuestra la terminación del bucle:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) x - r*r", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) x - r", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) x - r*(r + 1)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) r", TRUE);

-- Pregunta 21
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes es una función de cota para este bucle: [code]int i=0; bool encontrado=false;\nwhile (i<n && !encontrado){\n    if (v[i]>0)\n    {encontrado=true;}\n    else\n    {i=i+1;}\n}[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) n - i", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) i", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) n - i + 1", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de ellas.", TRUE);

-- Pregunta 22
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "En un problema de maximización resuelto con vuelta atrás la cota optimista o beneficio estimado:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) siempre puede ser el valor de la solución parcial.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) puede ser 0 si los beneficios son positivos.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) debe ser cota inferior de la mejor solución alcanzable.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", TRUE);

-- Pregunta 23
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "El coste de la poda de optimalidad puede ser tan elevado que no compense la poda conseguida.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Verdadero", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Falso", FALSE);

-- Pregunta 24
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> {\\(v.size \\geq 0\\)}\n\n[code]fun xxx(vector<int> v) dev int r[/code]\n\n{\\(r = \\max p, q : 0 \\leq p \\leq q \\leq v.size \\land \\forall i\\) \\(: p \\leq i < q : v[i] = 0 : q - p\\)}\n<br>y el vector de entrada v = [5, 4, 0, 4, 3, 0, 0, 0, 0, 5, 3, 0, 0, 5], ¿cuál es el valor de r según la especificación?");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) r = 7.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) r = 0.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) r = 4.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 25
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Un algoritmo óptimo que busca el máximo en un vector ordenado de n elementos tiene complejidad en el caso peor:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(\\log n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(1)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(n)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 26
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica la complejidad del siguiente algoritmo: [code]int c = 0;\nfor (int i = 1; i < n; i *= 2)\nfor (int j = 0; j < m+2; ++j)\nc += 4;[/code]");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) \\(\\Theta(1)\\)", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) \\(\\Theta(m \\log n)\\)", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) \\(\\Theta(nm)\\)", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 27
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dado un vector a de n enteros, con n ≥ 1, y una variable booleana b, el predicado \\(b = \\exists w : 0 \\leq w < n \\) \\( : (\\exists k : 0 \\leq k : a[w] = 2k + 1)\\)<br> significa que la variable b toma el valor cierto si y sólo si:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Hay al menos una posición en el vector que contiene un número impar positivo.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Nunca toma el valor cierto.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Todas las posiciones del vector son impares.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 28
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dada la especificación: <br> {\\(a.size \\geq 0\\)}\n\n[code]fun contarPares(vector<int> a)\n  dev int c\n\n[/code]{\\(c = \\#i : 0 \\leq i < a.\\text{size} : a[i] \\mod 2 = 0\\)}<br><br> y el siguiente algoritmo: [code]int contarPares(vector<int> const& a) {\nint c=0; int k=-1;\nwhile (k<a.size()-1)\n{\nif (a[k+1] % 2 == 0) {c=c+1;}\nk=k+1;\n}\nreturn c;\n}[/code] indica si el algoritmo es correcto con respecto a la especificación y en tal caso cuál es el invariante que permite demostrar la corrección del bucle.");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Es correcto con invariante {−1 ≤ k < a.size ∧ c = #i : 0 ≤ i < k : a[i] % 2 = 0}.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Es correcto con invariante {−1 ≤ k < a.size ∧ c = #i : 0 ≤ i ≤ k : a[i] % 2 = 0}.", TRUE),
(@test_fal_id, @pregunta_id, 3, "c) Es correcto con invariante {−1 ≤ k ≤ a.size ∧ c = #i : 0 ≤ i < n : a[i] % 2 = 0}.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Ninguna de las anteriores.", FALSE);

-- Pregunta 29
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de las siguientes afirmaciones sobre el algoritmo quicksort (ordenación rápida) es falsa:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Si los valores del vector están ordenados en orden creciente tiene un orden de complejidad cuadrático respecto al tamaño del vector.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Si los valores del vector presentan una distribución uniforme en un intervalo de valores, el algoritmo tiene una complejidad n log n siendo n el número de elementos del vector.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) El algoritmo tiene una complejidad n log n siendo n el número de elementos del vector tanto en el caso peor como en el caso medio.", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) El algoritmo tiene una complejidad cuadrática respecto al número de elementos del vector en el caso peor.", FALSE);

-- Pregunta 30
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Dos algoritmos que tienen el mismo orden de complejidad:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) Se comportan de forma semejante para tamaños de entrada grandes.", TRUE),
(@test_fal_id, @pregunta_id, 2, "b) Se comportan de forma semejante para tamaños de entrada pequeños.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Tardan exactamente el mismo tiempo en ejecutarse.", FALSE),
(@test_fal_id, @pregunta_id, 4, "d) Todas de las anteriores.", FALSE);

-- Pregunta 31
INSERT INTO `preguntas` (`ID_test`, `pregunta`) VALUES
(@test_fal_id, "Indica cuál de los siguientes es un requisito imprescindible para poder utilizar el algoritmo de la búsqueda binaria sobre un vector:");
SET @pregunta_id := LAST_INSERT_ID();
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`) VALUES
(@test_fal_id, @pregunta_id, 1, "a) El vector debe tener al menos un elemento.", FALSE),
(@test_fal_id, @pregunta_id, 2, "b) Los elementos del vector deben ser números enteros.", FALSE),
(@test_fal_id, @pregunta_id, 3, "c) Los valores del vector deben estar ordenados (según un orden bien definido).", TRUE),
(@test_fal_id, @pregunta_id, 4, "d) Todas las anteriores.", FALSE);

-- ----------------------------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------
-- ----------------------------------------------------------------------------------------------------------------------------

-- Insertar el test 'Simulacro Examen FAL'
INSERT INTO `tests` (`titulo`, `ID_usuario`, `num_preguntas`, `es_publico`, `es_anonimo`, `resta`) VALUES
('Simulacro Examen', 1, 10, TRUE, FALSE, 0.333);
SET @simulacro_fal_id := LAST_INSERT_ID();  -- Obtener el ID del nuevo test insertado

-- Asociar el nuevo test con la asignatura y la universidad
INSERT INTO `test_asignatura` (`ID_test`, `ID_universidad`, `ID_asignatura`) VALUES
(@simulacro_fal_id, @ucm_id, @fal_id);

-- Insertar las preguntas del banco de preguntas "Examen Teórico FAL" en el "Simulacro Examen FAL"
INSERT INTO `preguntas` (`ID_test`, `pregunta`)
SELECT @simulacro_fal_id, `pregunta`
FROM `preguntas`
WHERE `ID_test` = @test_fal_id;

-- Copiar las opciones asociadas a las preguntas del banco de preguntas al simulacro
-- Primero, se necesita obtener los IDs de las preguntas originales y las preguntas en el simulacro
-- Suponemos que las preguntas se insertan en el mismo orden que en el banco original

-- Asumimos que el ID de la primera pregunta del banco original es @first_question_id del banco y @first_simulacro_question_id del simulacro
SET @first_question_id := (SELECT MIN(`ID_pregunta`) FROM `preguntas` WHERE `ID_test` = @test_fal_id);
SET @first_simulacro_question_id := (SELECT MIN(`ID_pregunta`) FROM `preguntas` WHERE `ID_test` = @simulacro_fal_id);

-- Insertar opciones para cada pregunta del simulacro
INSERT INTO `opciones` (`ID_test`, `ID_pregunta`, `ID_opcion`, `opcion`, `correcta`)
SELECT @simulacro_fal_id, `ID_pregunta` + @first_simulacro_question_id - @first_question_id, `ID_opcion`, `opcion`, `correcta`
FROM `opciones`
WHERE `ID_test` = @test_fal_id AND `ID_pregunta` >= @first_question_id;