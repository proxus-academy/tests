<?php define('DB_NAME', 'flexam');
    // Entorno de desarrollo local
define('DB_HOST', 'localhost');
define('DB_USER', 'flexam');
define('DB_PASSWORD', 'Flexam24');
define('BASE_URL', 'https://proxustools.com/');
define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'] . '/');
define('COMMON_PATH', BASE_PATH . 'code/comun/');
define('VIEWS_PATH',
BASE_PATH . 'code/views/');
// Definir otras rutas relativas a BASE_URL si es necesario
define('STYLES_URL', BASE_URL . 'styles/');
define('RESOURCES_URL', BASE_URL . 'resources/');
?>