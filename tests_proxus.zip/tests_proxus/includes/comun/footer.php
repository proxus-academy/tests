<footer>
    <p>&copy; 2024 PROXUS Academy.</p>
    <p>Síguenos en Instagram:</p>
    <a href="https://www.instagram.com/proxusacademy/" target="_blank" class="Btn">
    <img src="https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/instagram-white-icon.png" alt="Instagram" style="max-width: 39px; margin-top: -5px;">
    </a>
</footer>
