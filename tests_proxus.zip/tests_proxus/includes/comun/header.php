<!DOCTYPE html>
<html>
<head>
    <title>PROXUS - Plataforma de Tests</title>
    <link rel="stylesheet" href="styles/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.00">
</head>
<body>
    <header>
        <div class="header-container">
            <a href="index.php">
                <img src="resources/imagenes/PROXUS_white_logo.png" alt="PROXUS logo" class="logo">
            </a>
            <div class="separator"></div>
            <nav>
                <ul>
                    <li><a href="https://www.proxusacademy.com" target="_blank" >Web</a></li>
                    <li><a href="https://proxus-academy-s-site.thinkific.com/courses/speedrun-fal" target="_blank" >SPEEDRUN</a></li>
                    <li><a href="index.php">Tests</a></li>
                    <?php
                        if (session_status() == PHP_SESSION_NONE) {
                            session_start();
                        }
                        if(isset($_SESSION['loggedin'])) {
                            // El usuario está registrado, mostramos su nombre:  $_SESSION['user']
                            // Se muestra 'Mi Perfil'
                            echo '<li><a href="user_menu.php">'. "Perfil" .'</a></li>';

                            // Comprobar si el usuario es admin
                            if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin') {
                                echo '<li><a href="admin_panel.php">Admin</a></li>'; // Enlace hacia el panel de administración
                            }

                            // Mostramos un enlace para cerrar sesión
                            echo '<li><a href="#" onclick="showPopup(); return false;">Salir</a></li>';
                        } else {
                            // El usuario no está registrado, mostramos un enlace al login
                            echo '<li><a href="login.php">Login</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Pop-up de Confirmación -->
    <div id="confirmationPopup" class="popup-overlay" style="display:none;">
        <div class="popup-content">
            <h2>¿Estás seguro de que quieres salir?</h2>
            <button onclick="closePopup()" class="btn-default">Cancelar</button>
            <a href="logic/logout.php" class="btn-primary"  style="text-decoration: none;">Salir</a>
        </div>
    </div>

    <script>
    function showPopup() {
        document.getElementById('confirmationPopup').style.display = 'flex'; // Cambio de 'block' a 'flex'
    }

    function closePopup() {
        document.getElementById('confirmationPopup').style.display = 'none';
    }
    </script>
</body>
</html>
