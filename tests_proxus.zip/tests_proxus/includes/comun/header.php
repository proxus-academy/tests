<!DOCTYPE html>
<html>
<head>
    <title>PROXUS - Plataforma de Tests</title>
    <link rel="stylesheet" href="styles/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.00">
</head>
<body>
    <header>
        <div class="header-container">
            <a href="index.php">
                <img src="resources/imagenes/PROXUS_white_logo.png" alt="PROXUS logo" class="logo">
            </a>
            <div class="separator"></div>
            <nav>
                <ul>
                    <li><a href="https://proxus-academy-s-site.thinkific.com/" target="_blank" >SPEEDRUNS</a></li>
                    <li><a href="index.php" style="border: 0.3px solid; border-radius: 7px; padding: 7px;"> <img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/tests.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;"> TESTS</a></li>
                    <?php
                        if (session_status() == PHP_SESSION_NONE) {
                            session_start();
                        }
                        if(isset($_SESSION['loggedin'])) {
                            // El usuario está registrado, mostramos su nombre:  $_SESSION['user']
                            // Se muestra 'Mi Perfil'
                            echo '<li><a href="user_menu.php"> <img src="https://www.proxusacademy.com/wp-content/uploads/2024/05/people.png" style="max-height: 20px; margin-bottom: -3px; margin-right: 5px;">'. "Mi Perfil" .'</a></li>';

                            // Comprobar si el usuario es admin
                            if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin') {
                                echo '<li><a href="admin_panel.php">Admin</a></li>'; // Enlace hacia el panel de administración
                            }

                        } else {
                            // El usuario no está registrado, mostramos un enlace al login
                            echo '<li><a href="login.php">Login</a></li>';
                        }
                    ?>
                </ul>
            </nav>
        </div>
    </header>
    <script>
        /* gestiona que se oculte el header al hacer scroll */
        let lastScrollTop = 0;
        let delta = 5; // Define cuántos píxeles debe moverse antes de ocultar/mostrar
        const header = document.querySelector('header');
        let headerHeight = header.offsetHeight; // Obtenemos la altura del encabezado

        window.addEventListener('scroll', function() {
            let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            // Asegúrate de que se mueva más de delta y que no esté en la parte superior de la página
            if (Math.abs(lastScrollTop - scrollTop) <= delta) return;

            if (scrollTop > lastScrollTop && scrollTop > headerHeight) {
                // Scroll hacia abajo
                header.style.top = `-${headerHeight}px`; // Asegúrate de que el encabezado se oculte completamente
            } else if (scrollTop + window.innerHeight < document.documentElement.scrollHeight) {
                // Scroll hacia arriba
                header.style.top = "0";
            }

            lastScrollTop = scrollTop;
        });

    </script>

</body>
</html>
