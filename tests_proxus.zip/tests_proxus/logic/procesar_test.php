<?php
session_start();
require_once '../includes/Aplicacion.php';

$db = Aplicacion::getInstance()->getConnection();
$test_id = isset($_POST['ID_test']) ? $_POST['ID_test'] : null;
$user_id = $_SESSION['ID_usuario'];
$total_preguntas = isset($_POST['total_preguntas']) ? intval($_POST['total_preguntas']) : 0;

if ($test_id === null) {
    exit('El ID del test no está definido.');
}

// Obtener el factor de resta
$stmtResta = $db->prepare("SELECT resta FROM tests WHERE ID_test = ?");
$stmtResta->bindParam(1, $test_id, PDO::PARAM_INT);
$stmtResta->execute();
$resta = $stmtResta->fetch(PDO::FETCH_ASSOC)['resta'];

// Inicialización de variables para contar respuestas correctas y incorrectas
$aciertos = 0;
$fallos = 0;

foreach ($_POST as $key => $value) {
    if (strpos($key, 'pregunta_') === 0 && !empty($value)) {
        $id_pregunta = substr($key, 9); // Extraer el ID de la pregunta desde el nombre del campo
        $opcion_seleccionada = intval($value);

        // Verifica si la opción seleccionada es correcta
        $stmtRespuestaCorrecta = $db->prepare("SELECT correcta FROM opciones WHERE ID_test = ? AND ID_pregunta = ? AND ID_opcion = ?");
        $stmtRespuestaCorrecta->bindParam(1, $test_id, PDO::PARAM_INT);
        $stmtRespuestaCorrecta->bindParam(2, $id_pregunta, PDO::PARAM_INT);
        $stmtRespuestaCorrecta->bindParam(3, $opcion_seleccionada, PDO::PARAM_INT);
        $stmtRespuestaCorrecta->execute();
        if ($stmtRespuestaCorrecta->fetch(PDO::FETCH_ASSOC)['correcta']) {
            $aciertos++; // Incrementa aciertos si la respuesta es correcta
        } else {
            $fallos++; // Incrementa fallos si la respuesta es incorrecta
        }
    }
}

// Calcular la nota considerando los fallos y la resta
$puntos = max(0, $aciertos - $fallos * $resta);
$nota = ($total_preguntas > 0) ? round(($puntos / $total_preguntas) * 10, 2) : 0; // Calcula la nota ajustada

$respuestas_en_blanco = $total_preguntas - $aciertos - $fallos;

// Guardar los resultados en la tabla respuesta_usuario
$sqlGuardarResultado = "INSERT INTO respuesta_usuario (ID_test, ID_usuario, nota, aciertos, fecha) VALUES (?, ?, ?, ?, NOW())";
$stmtGuardarResultado = $db->prepare($sqlGuardarResultado);
$stmtGuardarResultado->bindParam(1, $test_id, PDO::PARAM_INT);
$stmtGuardarResultado->bindParam(2, $user_id, PDO::PARAM_INT);
$stmtGuardarResultado->bindParam(3, $nota, PDO::PARAM_STR);
$stmtGuardarResultado->bindParam(4, $aciertos, PDO::PARAM_INT);
$stmtGuardarResultado->execute();

// Guardar en sesión para uso en resultados_test.php
$_SESSION['resultados_test'] = [
    'total_preguntas' => $total_preguntas,
    'aciertos' => $aciertos,
    'fallos' => $fallos,
    'resta' => $resta,
    'respuestas_en_blanco' => $respuestas_en_blanco,
    'nota' => $nota
];

// En procesar_test.php, guarda también las opciones seleccionadas por el usuario
foreach ($_POST as $key => $value) {
    if (strpos($key, 'pregunta_') === 0) {
        $id_pregunta = substr($key, 9);
        $respondida = !empty($value);
        $opcion_seleccionada = intval($value);
        $correcta = false;
        $cambio_puntuacion = 0;

        if ($respondida) {
            $stmtRespuestaCorrecta = $db->prepare("SELECT correcta FROM opciones WHERE ID_test = ? AND ID_pregunta = ? AND ID_opcion = ?");
            $stmtRespuestaCorrecta->bindParam(1, $test_id, PDO::PARAM_INT);
            $stmtRespuestaCorrecta->bindParam(2, $id_pregunta, PDO::PARAM_INT);
            $stmtRespuestaCorrecta->bindParam(3, $opcion_seleccionada, PDO::PARAM_INT);
            $stmtRespuestaCorrecta->execute();
            $correcta = $stmtRespuestaCorrecta->fetch(PDO::FETCH_ASSOC)['correcta'];

            if ($correcta) {
                $aciertos++;
                $cambio_puntuacion = 1; // Asumimos que cada acierto suma 1 punto, ajusta según tu lógica
            } else {
                $fallos++;
                $cambio_puntuacion = -$resta; // Resta es el porcentaje del valor de la pregunta que debe restarse
            }
        }

        $_SESSION['detalles_respuestas'][$id_pregunta] = [
            'respondida' => $respondida,
            'correcta' => $correcta,
            'opcion_seleccionada' => $opcion_seleccionada,
            'cambio_puntuacion' => $cambio_puntuacion
        ];
    }
}


// Redirección a resultados_test.php con los resultados disponibles en la sesión
header('Location: ../resultados_test.php?test_id=' . urlencode($test_id));
exit();
?>
