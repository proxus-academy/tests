<?php
require_once '../includes/Aplicacion.php';

// Preparar la respuesta para errores de validación
$errors = [];

// Asegurarse de que el método de solicitud sea POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'errors' => ['general' => 'Método de solicitud no válido.']]);
    exit;
}

$db = Aplicacion::getInstance()->getConnection();

// Validar los datos recibidos
$nombre = filter_var($_POST['nombre'] ?? '', FILTER_SANITIZE_STRING);
$apellidos = filter_var($_POST['apellidos'] ?? '', FILTER_SANITIZE_STRING);
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$user = filter_var($_POST['user'] ?? '', FILTER_SANITIZE_STRING);
$psw = $_POST['psw'] ?? '';
$psw_confirm = $_POST['psw_confirm'] ?? '';
$codigo_registro = $_POST['codigo_registro'] ?? '';

// Validaciones
if (empty($nombre)) $errors['nombre'] = 'El nombre es obligatorio.';
if (empty($apellidos)) $errors['apellidos'] = 'Los apellidos son obligatorios.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'El formato del email no es válido.';
if (empty($user)) $errors['user'] = 'El usuario es obligatorio.';
if (empty($psw) || empty($psw_confirm) || $psw !== $psw_confirm) $errors['psw-confirm'] = 'Las contraseñas no coinciden o están vacías.';
if (empty($codigo_registro)) $errors['codigo_registro'] = 'El código de registro es obligatorio.';

// Verificar si el nombre de usuario ya existe
$stmt = $db->prepare("SELECT `user` FROM `usuarios` WHERE `user` = ?");
$stmt->bindParam(1, $user);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $errors['user'] = 'Este nombre de usuario ya está en uso.';
}

// Verificar si el email ya está registrado
$stmt = $db->prepare("SELECT `email` FROM `usuarios` WHERE `email` = ?");
$stmt->bindParam(1, $email);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $errors['email'] = 'Este email ya está en uso.';
}

// Comprobar la validez del código de registro y obtener los IDs asociados
$stmt = $db->prepare("SELECT `codigo`, `ID_universidad`, `ID_grado` FROM `codigos_registro` WHERE `codigo` = ? AND `usado` = FALSE");
$stmt->bindParam(1, $codigo_registro);
$stmt->execute();
if ($stmt->rowCount() == 0) {
    $errors['codigo_registro'] = 'Código de registro inválido o ya utilizado.';
} else {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $id_universidad = $row['ID_universidad'];
    $id_grado = $row['ID_grado'];
}

// Si hay errores, devolverlos y detener la ejecución del script
if (!empty($errors)) {
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Si no hay errores, proceder con la lógica de inserción
$hashed_psw = password_hash($psw, PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO usuarios (user, psw, nombre, apellidos, email, ID_universidad, ID_grado, rol) VALUES (?, ?, ?, ?, ?, ?, ?, 'estudiante')");
$stmt->bindParam(1, $user);
$stmt->bindParam(2, $hashed_psw);
$stmt->bindParam(3, $nombre);
$stmt->bindParam(4, $apellidos);
$stmt->bindParam(5, $email);
$stmt->bindParam(6, $id_universidad);
$stmt->bindParam(7, $id_grado);

if ($stmt->execute()) {
    // Marcar el código como usado
    $stmt = $db->prepare("UPDATE `codigos_registro` SET `usado` = TRUE WHERE `codigo` = ?");
    $stmt->bindParam(1, $codigo_registro);
    $stmt->execute();
    
    echo json_encode(['success' => true, 'redirect' => 'bienvenida.php']);
} else {
    $errors['general'] = "Error al registrar usuario: " . $db->errorInfo()[2];
    echo json_encode(['success' => false, 'errors' => $errors]);
}
?>
