<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once "includes/Aplicacion.php";

function authenticate($user, $psw) {
    $db = Aplicacion::getInstance()->getConnection(); // Obtener la conexión a través del Singleton

    // La consulta SQL para seleccionar también el rol del usuario
    $sql = "SELECT ID_usuario, user, nombre, psw, rol FROM usuarios WHERE user = ?";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(1, $user);  // Usar bindParam() para vincular el parámetro $user al marcador de posición en la consulta SQL

    if($stmt->execute()){
        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            // Obtener también la contraseña hasheada y el rol del usuario de la base de datos
            $id = $row['ID_usuario'];
            $name = $row['nombre'];
            $hashed_psw = $row['psw'];
            $role = $row['rol'];  // Obtener el rol del usuario

            // Verificar la contraseña con el hash
            if(password_verify($psw, $hashed_psw)){
                // Iniciar nueva sesión si la contraseña coincide
                $_SESSION["loggedin"] = true;
                $_SESSION["ID_usuario"] = $id;
                $_SESSION["user"] = $user;
                $_SESSION["rol"] = $role;  // Guardar el rol en la sesión

                // Redireccionar al usuario a la página de inicio
                header("location: index.php");
                exit;
            }
        }
    }
    // Manejo de errores de usuario o contraseña inválidos
    return "Usuario o contraseña inválidos.";
}
?>
