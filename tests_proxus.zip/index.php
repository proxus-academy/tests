<?php include 'includes/comun/config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>PROXUS - Plataforma de Tests</title>
<script src="/js/functions.js?v=<?php echo time(); ?>"></script>
</head>
<body>
    <?php include 'includes/comun/header.php'; ?>
    <div class="container">
        <h1 class="text-center">Gánale a tu examen con PROXUS</h1>
        <div class="image-space">
            <img src="<?php echo BASE_URL; ?>resources/imagenes/fal_background.jpg" class="rounded-image">
        </div>
        <div class="separator-gray"></div>
        <p class="text-center">Esta plataforma está ideada por y para estudiantes, permitiéndote practicar los contenidos del TEST de FAL de manera
            que llegues al examen final y puedas clavarlo, habiendo interiorizado todo el proceso de enfrentarte al examen 
            las veces que quieras anteriormente.
        </p>
    </div>
    <?php include 'includes/comun/footer.php'; ?>
</body>
</html>
